"""
Collection of all physical registers\n
WARNING: This file is large and can slow scripts!\n
WARNING: Do not import more than ones!\n
!!! THIS FILE IS UNTOUCHABLE ... DO NOT EVEN TRY TO EDIT THIS !!!
"""

from typing import Any, Union, Literal

ABSTRACT_VALUE = 0b00000001
ABSTRACT_NOT_VALUE = 0b00000000