"""
Device | Keyboard `root` file
"""
import sys, os, random as r
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '../../')))

from OS.syst.kernel.core.ALL import *

class Controller():
    
    def __init__(self):
        pass
    
    
    