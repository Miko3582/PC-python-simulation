import sys, os, time, threading as t, random as r, datetime
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '../../')))
from OS.syst.kernel.core.regs import *

class Init():
    
    def __init__(self, dev_path, dev_name, args=[]):
        
        # SYS
        self._lockf = t.Lock() # lock while editing files (for threading ops.)
        
        X_SATA_ADDR_START = dev_path
        X_SATA_ADDR_END = dev_name
        if args: 
            X_SATA_MODE = args
    
        # save in class cache
        self.devpath = X_SATA_ADDR_START
        self.devname = X_SATA_ADDR_END
    
    # get configuration from `/meta` device-conifg file 
    def load_cfg(self, cfg_file): ...
    def repair_cfg(self): ...
    def rm_cfg(self): ...
    
    #.TODO: SATA port section (future)
    # $...

class HAL(Init):
    """Part for hardware control"""
    
    def __init__(self, dev_path, dev_name, args=[]):
        super().__init__(dev_path, dev_name, args)
        
        #? pointer for dev dir
        X_SATA_P0 = os.path.join(self.devpath, self.devname)
        self.__disk = X_SATA_P0 # actual disk
        self.__part = X_SATA_S0 # actual partition
        
        self.rsv_blocks_list = []
        
        
    # blocks
    def block_rsv(self, block_id):
        """reserv block for i/o operation\n
        Return True, RBL, info_msg & key, False & warn_msg otherwise
        """
        
        """
        WARN: This function is not connected to saving data in block, its only reserving block FOR other operation, 
        to avoid situation when there is no free space, while using threading. To get access to reserved block (not RBL (reserved blocks list)),
        special key is needed. The `/meta/alloc.meta` file is responsible for this, built of: [BLOCK_ID; STATUS (`ALLOCATED` or `FREE`); 
        res_bit], where `res_bit` is set to 1 if block is reserved, 0 otherwise.
        """
        
        # set default
        X_16_SATA_LOCAL_BUFF = []  # used to edit & save block flag from file
        X_64_SATA_LOCAL_BUFF = self.rsv_blocks_list # use lbuff-64 as an map for reserved blocks (loads existing when entering function)
        X_256_SATA_LOCAL_BUFF = [] # copy of whole file content (while editing)
        
        X_SATA_R0 = self.__disk
        X_SATA_R1 = "meta"
        X_SATA_R2 = "alloc.meta"
        X_SATA_R3 = CONST_OFFSET_FALSE
        X_SATA_R4 = CONST_OFFSET_FALSE
        X_SATA_R5 = CONST_OFFSET_FALSE
        
        X_SATA_P0 = os.path.join(X_SATA_R0, X_SATA_R1, X_SATA_R2) # abs_path to `alloc.meta` file
        X_SATA_P1 = block_id
        
        # check if block is not reserved (fasted method to catch reserved blocks)
        if X_SATA_P1 in X_64_SATA_LOCAL_BUFF:
            return False, "WARN: Block is already reserved; exists in RBL (Reserved Blocks List) -> [*lbuff-64]"
        
        # get file content and save in lbuff-256
        with self._lockf:
            X_SATA_F0 = open(X_SATA_P0, "r+")
            X_256_SATA_LOCAL_BUFF = X_SATA_F0.readlines()

        # iterate on `alloc.meta` file, find block, check if not reserved & and reserve
        # return True, RBL & info msg if everythink is okey (block is not reserved | block not in RBL), return False & warning_msg otherwise
        for i, line in enumerate(X_256_SATA_LOCAL_BUFF):
            
            # find block line
            if line.startswith(f"block_{X_SATA_P1}:"):
                print(line)
                X_SATA_R3 = line.strip().split(":")[1]
                X_SATA_R4 = int(X_SATA_R3.strip().split(';')[1])
                if X_SATA_R4 == 1:
                    return False, "WARN: Block is already reserved!"
                
                # replace `res_bit` from 0 with 1
                X_16_SATA_LOCAL_BUFF = [x for x in X_256_SATA_LOCAL_BUFF[i]]
                X_16_SATA_LOCAL_BUFF = ''.join([x.replace("0", "1") for x in X_16_SATA_LOCAL_BUFF])
                X_256_SATA_LOCAL_BUFF[i] = X_16_SATA_LOCAL_BUFF
                break
        
        # clear file & write data from lbuff-256 to file
        with self._lockf:
            X_SATA_F0 = open(X_SATA_P0, "w+")
            for line in X_256_SATA_LOCAL_BUFF:
                X_SATA_F0.write(line)
            X_SATA_F0.close()
        
        # generate 8-bit key and write to lbuff-64 as [key, block_od]
        X_SATA_C0 = 8
        X_SATA_R5 = ''.join(str([r.randrange(0,9)] for _ in range(X_SATA_C0)))
        X_64_SATA_LOCAL_BUFF.append([X_SATA_R5, X_SATA_P1])

        #
        self.rsv_blocks_list = X_64_SATA_LOCAL_BUFF
        return True, X_64_SATA_LOCAL_BUFF, "INFO: Block reserved succesfully", X_SATA_R5

    def block_rls(self, block_id, key:int):
        """release block after i/o operation\n
        Return True, RBL & info_msg, False & warn_msg otherwise
        """
        
        # set default
        X_16_SATA_LOCAL_BUFF = []  # used to edit & save block flag from file
        X_64_SATA_LOCAL_BUFF = self.rsv_blocks_list # use lbuff-64 as an map for reserved blocks (loads existing when entering function)
        X_256_SATA_LOCAL_BUFF = [] # copy of whole file content (while editing)
        
        X_SATA_R0 = self.__disk
        X_SATA_R1 = "meta"
        X_SATA_R2 = "alloc.meta"
        X_SATA_R3 = CONST_OFFSET_FALSE
        X_SATA_R4 = CONST_OFFSET_FALSE
        X_SATA_R5 = key
        
        X_SATA_P0 = os.path.join(X_SATA_R0, X_SATA_R1, X_SATA_R2) # abs_path to `alloc.meta` file
        X_SATA_P1 = block_id
        
        # check if block is reserved (fasted method to catch reserved blocks)
        if X_SATA_P1 not in X_64_SATA_LOCAL_BUFF:
            return False, "WARN: Block is not reserved; not exists in RBL (Reserved Blocks List) -> [*lbuff-64]"
        
        # confirm 8-bit key and remove entry (key, block_id) from lbuff-64
        for pair in X_64_SATA_LOCAL_BUFF:
            # instead of declaring in `for in` object | this is why we didnt use special variables naming
            key, block_id = pair[0], pair[1]
            
            # check if key and block ID is match with those in RBL & remove, return False & err_msg otherwise 
            if (key == X_SATA_R5) & (block_id == X_SATA_P1):
                X_64_SATA_LOCAL_BUFF.remove(pair)
                
            else: return False, "ERR: `key` does not match `block_id` in RBL!"
        
        # get file content and save in lbuff-256
        with self._lockf:
            X_SATA_F0 = open(X_SATA_P0, "r+")
            X_256_SATA_LOCAL_BUFF = X_SATA_F0.readlines()

        # iterate on `alloc.meta` file, find block, check if reserved & and release
        # return True, RBL & info msg if everythink is okey (block is reserved | block in RBL), return False & warning_msg otherwise
        for i, line in enumerate(X_256_SATA_LOCAL_BUFF):
            
            # find block line
            if line.startswith(f"block_{X_SATA_P1}:"):
                X_SATA_R3 = line.strip().split(":")[1]
                X_SATA_R4 = int(X_SATA_R3.strip().split(';')[1])
                if X_SATA_R4 == 0:
                    return False, "WARN: Block is not reserved!"
                
                # replace `res_bit` from 1 with 0
                X_16_SATA_LOCAL_BUFF = [x for x in X_256_SATA_LOCAL_BUFF[i]]
                X_16_SATA_LOCAL_BUFF = ''.join([x.replace("1", "0") for x in X_16_SATA_LOCAL_BUFF])
                X_256_SATA_LOCAL_BUFF[i] = X_16_SATA_LOCAL_BUFF
                break
        
        # clear file & write data from lbuff-256 to file
        with self._lockf:
            X_SATA_F0 = open(X_SATA_P0, "w+")
            for line in X_256_SATA_LOCAL_BUFF:
                X_SATA_F0.write(line)
            X_SATA_F0.close()

        #
        self.rsv_blocks_list = X_64_SATA_LOCAL_BUFF
        return True, X_64_SATA_LOCAL_BUFF, "INFO: Block reserved succesfully"

    def block_write(self, data:str, path, blocks_range=[-1, -1], res_blocks=False, meta=[], args=[]):
        """write data to block\n
        - - -
        - `data` - in ASCII format
        - `path` - abs path from OS [start with "DISK://root"]
        - `blocks_range` - as list [start, end] ; will be verified anyway
        - `res_blocks` - flag that inform if reserving blocks is needed
        - `meta` - as list [obj-type, layer, content_exists, perm]
        - `args` - as dict [flag -> value] (*OPTIONAL)
        
        - - -
        In `args` you will be able to put a lot of configurations and spec. options here, but not yet!\n
        `blocks_range` is not required (if `-1`)- function will automatically assign data to block/s in first free foundt space.
        """
        
        #NOTE: If `S` after '#' its mean, that part of code is critical, under special control, etc. Do not edit!
        #NOTE: Some of vars declatarion will be did more than ones, cos of limited space & vars (overwrite in other code sections)

        # GET_TIME ->   {time.strftime("%Y.%m.%d %H:%M:%S")}
        
        # set default
        #NOTE: These descriptions concern first uses of lbuffs, but in other code sections they has other uses (they are also described there).
        #NOTE: If description has `%` thats mean, lbuff has only one usage.
        
        #% X_SATA_C1 -> amount of data to write 
         
        X_16_SATA_LOCAL_BUFF =  [] #% holds enumerated blocks ID's
        X_32_SATA_LOCAL_BUFF =  [] #  holds splitted path segments
        X_64_SATA_LOCAL_BUFF =  [] #% holds splitted data (ascii, then binary)   
        X_128_SATA_LOCAL_BUFF = [] #  holds `dirs.meta` file content 
        X_256_SATA_LOCAL_BUFF = [] #% holds `part_table.part` file content
        X_512_SATA_LOCAL_BUFF = [] # holds `alloc.meta` file content
        
        X_SATA_R0 = self.__disk
        X_SATA_R1 = self.__part
        X_SATA_S0 = path
        
        # generate 8-bit ID
        X_SATA_S11 = r.randrange(10000000, 99999999) # operation 8-bit ID
        
        ## sys-log ~ (starting write operation on block)
        X_SATA_P0 = "log"
        X_SATA_P1 = "sys.log"
        
        with self._lockf:
            X_SATA_F0 = open(file=os.path.join(X_SATA_R0, X_SATA_P0, X_SATA_P1), mode="a+")
            X_SATA_F0.write(f"{X_SATA_S11} | {time.strftime("%Y.%m.%d %H:%M:%S")} | BWO started at partition: [{X_SATA_R1}]\n\n")
            X_SATA_F0.close()
        
        ## op-log ~ (operation info & others)
        X_SATA_P0 = "log"
        X_SATA_P1 = "op.log"
        X_SATA_R2 = meta[0]
        X_SATA_R3 = meta[1]
        X_SATA_R4 = meta[2]
        X_SATA_R5 = meta[3]
        
        with self._lockf:
            X_SATA_F0 = open(file=os.path.join(X_SATA_R0, X_SATA_P0, X_SATA_P1), mode="a+")
            X_SATA_F0.write(f"{X_SATA_S11} | {time.strftime("%Y.%m.%d %H:%M:%S")} | {X_SATA_R2};{X_SATA_R3};{X_SATA_R4};{X_SATA_R5}\n\n")
            X_SATA_F0.close()
        
        #S.TODO: check permissions
        #.TODO: type of data (file/dir)
        
        # prepare path segments
        X_SATA_R2 = path
        X_32_SATA_LOCAL_BUFF = X_SATA_R2.split("/")
        X_SATA_R3 = X_32_SATA_LOCAL_BUFF[CONST_OFFSET_FALSE] # `/root` index
        X_SATA_R4 = X_32_SATA_LOCAL_BUFF[-CONST_OFFSET_TRUE] # `obj` index
        
        # checks entry in /meta
        #.TODO: write `alloc.meta` file handling section (mainly for checking dentisity and calc actual amount of blocks)
        #.OLD: $ X_SATA_P1 = "alloc.meta" # for now, that var is not used in this place, but will be
        
        X_SATA_P0 = "meta"
        X_SATA_P2 = "dirs.meta"
        
        X_SATA_F0 = open(file=os.path.join(X_SATA_R0, X_SATA_P0, X_SATA_P2), mode="r+")
        X_128_SATA_LOCAL_BUFF = X_SATA_F0.readlines()
        for line in X_128_SATA_LOCAL_BUFF:
            if X_SATA_R2 in line:    
                return FileExistsError("ERR: Object exists in the current location.")
            
        #.TODO: checks entry in /part
        
        #S load partition
        # here lbuff-128 is used to hold all partition section from file
        X_SATA_P0 = "part"
        X_SATA_P1 = "part_table.part"
        X_SATA_F0 = open(file=os.path.join(X_SATA_R0, X_SATA_P0, X_SATA_P1), mode="r+")
        X_256_SATA_LOCAL_BUFF = X_SATA_F0.readlines()
        X_SATA_P2 = 12 # amount of lines to get whole partition section for `part_table.part` (except "[NAME]" and ";")
        
        X_128_SATA_LOCAL_BUFF = [] # holds partition entry from `part_table.part` file
        for i, line in enumerate(X_256_SATA_LOCAL_BUFF):
            if line == f"[{X_SATA_R1}]":
                i+=1
                X_SATA_P3 = i + X_SATA_P2
                # break when pointer ends or line equ ";" char
                while i < X_SATA_P3:
                    if line != ';': break
                    X_128_SATA_LOCAL_BUFF.append(X_256_SATA_LOCAL_BUFF[i])
                    i+=1
        
        ## part-log
        X_SATA_P0 = "log"
        X_SATA_P1 = "part.log"
        
        with self._lockf:
            X_SATA_F0 = open(file=os.path.join(X_SATA_R0, X_SATA_P0, X_SATA_P1), mode="a+")
            X_SATA_F0.write(f"{X_SATA_S11} | {time.strftime("%Y.%m.%d %H:%M:%S")} | Get entry from partition [PT]: [{X_SATA_R1}]\n\n")
            X_SATA_F0.close()
            
        # check (free-space, needed-space, control-sums, data-accuracy)
        #S conv data to BIN
        #NOTE: sizes in B, not in blocks (this is in other code section)
        
        # data on entry in ascii repr. -> bin repr.
        # data format fe: 59 71 66 32
        # data format fe: 0010 0110 0011 1000
        # contol sum: 6 (sum of 1 in bin-datas) * 1024
        
        X_SATA_CS = CONST_OFFSET_FALSE # custom reg for CS -> [Control Sum]
        X_SATA_R2 = data
        X_64_SATA_LOCAL_BUFF = X_SATA_R2.split()
        X_64_SATA_LOCAL_BUFF = [bin(int(x)) for x in X_64_SATA_LOCAL_BUFF]
        X_SATA_CS = sum("1" for y in x for x in X_64_SATA_LOCAL_BUFF) * 1024
        X_SATA_S1 = len(X_64_SATA_LOCAL_BUFF) # needed space in bytes
        X_SATA_FSIZE = X_128_SATA_LOCAL_BUFF[5]
        
        X_SATA_P1 = str(X_128_SATA_LOCAL_BUFF[6]).split('=')[1] #TIP: get only value, without key `brange=`
        X_SATA_ADDR_START, X_SATA_ADDR_END = X_SATA_P1.split(',')
        
        ## dev-log
        X_SATA_P0 = "log"
        X_SATA_P1 = "dv.log"
        
        with self._lockf:
            X_SATA_F0 = open(file=os.path.join(X_SATA_R0, X_SATA_P0, X_SATA_P1), mode="a+")
            X_SATA_F0.write(f"{X_SATA_S11} | {time.strftime("%Y.%m.%d %H:%M:%S")} | Checking completed on part-table for partition [PT]: [{X_SATA_R1}]\n\n")
            X_SATA_F0.close()
        
        # calc amount of blocks needed to store data
        #.TODO: Get blcoks in blocks range from partition entry (brange -> part_table.part)
        #NOTE: Default allocation size is 64B not 4096B like in real fs's
        
        # load alloc_size () & conv to bytes
        X_SATA_C0 = X_128_SATA_LOCAL_BUFF[7] * 1024 
        X_SATA_C1 = X_SATA_S1 / X_SATA_C0
        
        # if less, smallest alloc size is default 1 block
        if X_SATA_C1 < 1: X_SATA_C1 = 1
        
        # find first free blocks
        X_SATA_P0 = "meta"
        X_SATA_P1 = "alloc.meta"
        X_SATA_F0 = open(file=os.path.join(X_SATA_R0, X_SATA_P0, X_SATA_P1), mode="r+")
        
        # using lbuff-512 cos of cfg file size (~162.7 KB)
        X_512_SATA_LOCAL_BUFF = X_SATA_F0.readlines()
        X_SATA_C2 = CONST_OFFSET_FALSE
        
        for i, line in enumerate(X_512_SATA_LOCAL_BUFF):
            # wait until index in partition start range
            while i < X_SATA_ADDR_START:
                continue
            if X_SATA_C2 == X_SATA_C1: break # simplier & more readable method
            if "FREE" in line:
                X_SATA_C2+=1
                # save blocks ID to res & alloc in lbuff-16
                X_16_SATA_LOCAL_BUFF.append(i) 
                
        # reservs block/s if needed
        #NOTE: Even if block wasnt reserved succesfully (already reserved by sth else) function dont stopping, 
        # only part that change is op-log, nothing else.
        #NOTE: Function will continue write other blocks while waiting for those reserved to release.
        
        X_SATA_C2 = CONST_OFFSET_FALSE
        X_SATA_C3 = CONST_OFFSET_FALSE
        
        X_32_SATA_LOCAL_BUFF = [] # holds blocks [id, key]
        
        #.TODO: write code section if reserving blocks is not required
        if res_blocks:
            for i, block_id in enumerate(X_16_SATA_LOCAL_BUFF):
                
                # get rsv fucntion returns as tuple & save key in lbuff-32 as [block_id, block_key]
                # keys needed for realesing blocks in other code section
                X_SATA_F1 = self.block_rsv(block_id=block_id)
                if X_SATA_F1[CONST_OFFSET_FALSE] == CONST_OFFSET_BTRUE: X_SATA_C3 += 1
                else: X_SATA_C2 += 1
                X_32_SATA_LOCAL_BUFF.append([block_id, X_SATA_F1[-CONST_OFFSET_TRUE]])
                X_16_SATA_LOCAL_BUFF[i] = [block_id, X_SATA_F1[CONST_OFFSET_FALSE]] # overwrite lbuff-16 as pairs: [block_id, status]
                
        ## op-log
        X_SATA_P0 = "log"
        X_SATA_P1 = "op.log"
        
        with self._lockf:
            X_SATA_F0 = open(file=os.path.join(X_SATA_R0, X_SATA_P0, X_SATA_P1), mode="a+")
            X_SATA_F0.write(f"{X_SATA_S11} | {time.strftime("%Y.%m.%d %H:%M:%S")} | Allocated blocks={X_SATA_C3}; Not allocated blocks={X_SATA_C2}; [AC]\n\n")
            X_SATA_F0.close()
        
        #S load data to block/s
        
        # split & asign data to blocks using lbuff-256
        # Used method: loads data to block until its full, calc size of data in block, next jump to next one and repeat,
        # if block is reserved, set aside calc amount of data for future and jump to next iteration

        
        for i, block_id in enumerate(X_16_SATA_LOCAL_BUFF):
            # reg that control amount iterations of data writing to block
            # 1 iteration = 8-bits of data [cos of binary repr.]
            # alloc size equels iteration size
            X_SATA_S10 = CONST_OFFSET_FALSE # counter for writing iteration on block
            
            if X_32_SATA_LOCAL_BUFF[i][1] == CONST_OFFSET_BFALSE:
                
                # wait until block will be free
                # while not false = true -> repeat if reserved
                # while not true = false -> break if free

                #NOTE: We waiting, not when calling `block_rsv`, cos of that we dont want to wait to much 
                # time in one section (both sections is expensive cos of function calling)
                #.TODO: Check if we can modify `block_rsv` function to wait for already reserved block inside, instead of calling multiply times.
                
                X_SATA_F1 = CONST_OFFSET_BFALSE
                while not X_SATA_F1:
                    X_SATA_F1 = self.block_rsv(block_id=block_id)
                    if X_SATA_F1[CONST_OFFSET_FALSE] == CONST_OFFSET_BTRUE:
                        break
                    
            with self._lockf:
                X_SATA_P1 = f"block_{block_id}"
                X_SATA_F0 = open(file=os.path.join(X_SATA_R0, X_SATA_P0, X_SATA_P1), mode="w+")

                # set block size
                for i in range(X_SATA_C1):
                    X_SATA_F0.write(f"{X_64_SATA_LOCAL_BUFF[i]}\n")
                X_SATA_F0.close()

        
        ## dev-log
        X_SATA_P0 = "log"
        X_SATA_P1 = "dv.log"
        
        with self._lockf:
            X_SATA_F0 = open(file=os.path.join(X_SATA_R0, X_SATA_P0, X_SATA_P1), mode="a+")
            X_SATA_F0.write(f"{X_SATA_S11} | {time.strftime("%Y.%m.%d %H:%M:%S")} | Loaded & assigned data to blocks. [*D]\n\n")
            X_SATA_F0.close()
        
        
        ## i-log
        X_SATA_P0 = "log"
        X_SATA_P1 = "i.log"
        
        with self._lockf:
            X_SATA_F0 = open(file=os.path.join(X_SATA_R0, X_SATA_P0, X_SATA_P1), mode="a+")
            X_SATA_F0.write(f"{X_SATA_S11} | {time.strftime("%Y.%m.%d %H:%M:%S")} | @MILT: Data written on /dev/{X_SATA_R0} [**]\n\n")
            X_SATA_F0.close()
        
        # release block/s if were reserved
        #.TODO: Add exceptions code section if any errors or bugs occured.
        for pack in X_32_SATA_LOCAL_BUFF:
            block_id = pack[CONST_OFFSET_FALSE]
            key = pack[-CONST_OFFSET_TRUE]
            self.block_rls(block_id=block_id, key=key)
            
        # update /meta files & entries
        X_SATA_R2 = str(meta[0])
        X_SATA_P0 = "meta"
        X_SATA_P1 = f"{X_SATA_R2.lower()}.log"
        
        # get first and last written blocks
        X_SATA_R3 = X_16_SATA_LOCAL_BUFF[CONST_OFFSET_FALSE]
        X_SATA_R4 = X_16_SATA_LOCAL_BUFF[-CONST_OFFSET_TRUE]
        
        # use "1000" instead of "1000:1000" blocks range format if used only 1 block for operation 
        # for simplicity : ("start:stop" -> "start" if "start" == "stop")
        X_SATA_R5 = f"{X_SATA_R3}!{X_SATA_R4}" if X_SATA_R3 < X_SATA_R4 else f"{X_SATA_R3}"
        
        with self._lockf:
            X_SATA_F0 = open(file=os.path.join(X_SATA_R0, X_SATA_P0, X_SATA_P1), mode="a+")
            X_SATA_F0.write(f":{path}, {X_SATA_R2.upper()}, {X_SATA_R5}")
            X_SATA_F0.close()
        
        # update /part values
        X_512_SATA_LOCAL_BUFF = [] # holds `part_table.meta` (whole content)
        X_SATA_P0 = "part"
        X_SATA_P1 = "part_table.part"
        with self._lockf:
            X_SATA_F0 = open(file=os.path.join(X_SATA_R0, X_SATA_P0, X_SATA_P1), mode="r+")
            X_512_SATA_LOCAL_BUFF = X_SATA_F0.readlines()
            X_SATA_F0.close()
        
        # update `usize` value for actual partition in part entry using offset method
        #special vars for io-wrapper
        offset1 = 5 # usize key
        offset2 = 6 # fsize key
        
        for i, line in X_512_SATA_LOCAL_BUFF:
            if line == f"[{X_SATA_R1}]":
                
                # usize update
                X_SATA_P2 = i + offset1
                X_SATA_R2 = int(X_512_SATA_LOCAL_BUFF[X_SATA_P2].split("=")[1])
                X_512_SATA_LOCAL_BUFF[X_SATA_P2] = X_SATA_R2 + X_SATA_S1
                
                # fsize update
                X_SATA_P2 = i + offset2
                X_SATA_R2 = int(X_512_SATA_LOCAL_BUFF[X_SATA_P2].split("=")[1])
                X_512_SATA_LOCAL_BUFF[X_SATA_P2] = X_SATA_R2 + X_SATA_S1

        ## part-log
        X_SATA_P0 = "log"
        X_SATA_P1 = "op.log"
        
        with self._lockf:
            X_SATA_F0 = open(file=os.path.join(X_SATA_R0, X_SATA_P0, X_SATA_P1), mode="a+")
            X_SATA_F0.write(f"{X_SATA_S11} | {time.strftime("%Y.%m.%d %H:%M:%S")} | Updated entries values for `usize` & `fsize` [PT]\n\n")
            X_SATA_F0.close()

        """
        #.TODO: /root part (not yet) 
        # check (object-existence, permissions flags & cfg, other obj cfg) 
        ## root-log
        #.TODO: check (entries in /meta, control-sums, paths)
        """

        ## op-log
        X_SATA_P0 = "log"
        X_SATA_P1 = "op.log"
        
        with self._lockf:
            X_SATA_F0 = open(file=os.path.join(X_SATA_R0, X_SATA_P0, X_SATA_P1), mode="a+")
            X_SATA_F0.write(f"{X_SATA_S11} | {time.strftime("%Y.%m.%d %H:%M:%S")} | @MILT: Write operation ended with code 0. [**]\n\n")
            X_SATA_F0.close()
        
        ## sys-log
        X_SATA_P0 = "log"
        X_SATA_P1 = "sys.log"
        
        with self._lockf:
            X_SATA_F0 = open(file=os.path.join(X_SATA_R0, X_SATA_P0, X_SATA_P1), mode="a+")
            X_SATA_F0.write(f"{X_SATA_S11} | {time.strftime("%Y.%m.%d %H:%M:%S")} | @MILT: Code 0 for /dev/{X_SATA_R0} [**]\n\n")
            X_SATA_F0.close()
        
        
        ## err-log (if any occured)

    def block_read(block_id):
        "read data from block"
        
    def block_clear():
        "clean data from block"
    
    #NOTE: Part for memory is mainly to improve speed of transfer (while operating on big data packages)
    # by copying data packages to RAM, instead of directly to cpu
    def mblock_load():
        "load block to memory"
        
    def mblock_rls():
        "release block from memory"
    
    block_rls()
    mblock_rls()
    
class FS(HAL):
    def __init__(self, dev_path, dev_name, args=[]):
        super().__init__(dev_path, dev_name, args)

class Debug:
    ...    

class Utils:
    ...
    
hal = HAL(dev_path=r'/home/raw/Pulpit/PC/OS/dev', dev_name="E")
x = hal.block_rsv(9, rsv_blocks=[])
print(x)