# this file will be removed and we will write new version, based on "new" type of programming
# use this file to refactor new version of main SATA interface
# + now filesystems, drivers and interface will be separated as modules & files

#!

# MAIN SATA INTERFACE FILE

#^  MAIN IMPORTS
import time, os, random, shutil, math
import threading as t

#^  MAIN MODULES
class SATAHardwareLogicConnection:
    def __init__(self):
        self.path = r"/home/raw/Pulpit/PC/OS/dev"
        self.DATA = False
        self.READABLE = False
        self.ROOT = False
        
    def I_BASE_64(self,dev):
        try:
            self.DEV = os.path.join(self.path, dev)
            for obj in os.listdir(self.DEV):
                if os.path.isdir(obj):
                    if obj == "data": self.DATA = True
                    if obj == "root": self.ROOT = True   
                if os.path.isfile(obj):
                    if obj == "superblock.cfg" or obj == "_base64.cfg":
                        self.READABLE = True
            
                mode = False
                access = False
                dev_per = "~" #*  default
                dev_name = self.DEV.split('/')[-1]

                if self.DATA is True: access = True
                if self.READABLE is True: dev_per = "111"
                if self.ROOT is True: mode = True
                
                return [[mode,access],[dev_name,self.DEV,dev_per]]
        except: 
            print("Device not readable/acceptable.")
            print("Please verify/modify Interaface or fix device!")
            time.sleep(3)
            exit()
    
    def O_BASE_64(self): ... 
class SATASelfInterface:
    """`KERNEL` INTERFACE BASE CLASS"""
    def __init__(self):
        self.devs = r"/home/raw/Pulpit/PC/OS/dev"
        self.disk = 'C'
        self.path = os.path.join(self.devs,self.disk)
        self.bitmap_inodes = os.path.join(self.path,'meta/bitmap_inodes.dat')
        self.bitmap_blocks = os.path.join(self.path,'meta/bitmap_blocks.dat')
        self.inodes = os.path.join(self.path, 'inodes')
        self.vars = os.path.join(self.path, 'root/var')
        self.data = os.path.join(self.path, 'data')
        self.etc = os.path.join(self.path, 'root/etc')
        
    def I_(self,dev):
        [[mode,access],[dev_name,dev_path,dev_per]] = SATAHardwareLogicConnection.I_BASE_64(dev)
    def O_(self,dev): ...
    def IO_(self,dev):
        [[mode,access],[dev_name,dev_path,dev_per]] = SATAHardwareLogicConnection.I_BASE_64(dev)
        [[mode,access],[dev_name,dev_path,dev_per]] = SATAHardwareLogicConnection.O_BASE_64(dev)
    
    def type_(self):
        for dev in os.listdir(self.devs):
            dev_path = os.path.join(self.devs,dev)
            for obj in os.listdir(dev_path):
                
                if os.path.isdir(obj) and obj == "boot":
                    #& get device mode from `/boot/grub.cfg` file
                    try:
                        with open(os.path.join(dev_path, obj ,"grub.cfg"),'r+') as f:
                            mode = -1
                            for line in f:
                                if line.startswith("MODE="): 
                                    mode = int(line.strip().split("MODE=")[1])
                    except:
                        print("Device boot config file not readable/acceptable.")
                        print("Please verify/modify Interaface or fix device!")
                        time.sleep(3)
                        exit()
                        
            if mode == 0:
                SATASelfInterface.I_(dev)
            elif mode == 1:
                SATASelfInterface.O_(dev)
            elif mode == 2:
                SATASelfInterface.IO_(dev)
            elif mode == -1:
                print("Device is unable to connect!")
                print("Fix it!")
                time.sleep(3)
                exit()
            else:
                SATABiosConnection #^ FIX `boot/grub.cfg` FILE
                
    #&  ADD MORE EXCEPTIONS
    def __logs__(self, optype:str, status:int, data:list, info:str, path):
        """
        Depending on `optype` value from available:\n~
        [`efi_mbr` / `part` / `operations` / `dirs`]\n~
        IF `efi_mbr` data value:\n
        - BBP
        - BBTLD
        - MP
        - NAME
        - SPACE
        \n
        IF `part` data value:\n
        - BBP
        - MP
        - NAME
        - SPACE
        \n
        IF `operations` data value:\n
        - OP
        - BCONTENT
        - PER
        - FILE_PATH
        \n
        IF `dirs` data value:\n
        - BCONTENT:
        - PER
        - DIR_PATH
        """
        logs_path = os.path.join(path,'logs')
        create_time = time.strftime('%H:%M:%S | %Y-%m-%d')
        
        if optype == 'efi_mbr':
            
            part_logfile = os.path.join(logs_path,'sys.log')
            with open(part_logfile,'a+') as f:
                #TIME:STATUS:INFO
                #BBP:BBTLD:MP:NAME:SPACE
                
                if status == 1: status = 'SYSTEM'
                if status == 2: status = 'BOOTLOADER'
                if status == 3: status = 'AUTO'
                else: status = 'FAILED'
                f.write(f"\nTIME:{create_time} || STATUS:{status} || INFO: '{info}'\n")
                f.write(f"BBP:{data[0]} # BBTLD:{data[1]} # MP:/{data[2]} # NAME:'{data[3]}' # SPACE [MB]:{data[4]}\n\n")

            return True, 0
        
        if optype == 'part':
            
            part_logfile = os.path.join(logs_path,'part.log')
            with open(part_logfile,'a+') as f:
                #TIME:STATUS:INFO
                #FS:BBP:MP:NAME:SPACE
                
                if status == 1: status = 'CREATED'
                else: status = 'FAILED'
                f.write(f"\nTIME:{create_time} || STATUS:{status} || INFO: '{info}'\n")
                f.write(f"FS:{data[0]} # BBP:{data[1]} # MP:/{data[2]} # NAME:'{data[3]}' # SPACE [MB]:{data[4]}\n\n")

            return True, 0
        
        if optype == 'operations':
            
            op_logfile = os.path.join(logs_path, 'operations.log')
            with open(op_logfile,'a+') as f:
                #TIME:STATUS:INFO
                #OP:BCONTENT:PER:FILE_PATH
            
                if status == 1: status = 'CREATED'
                elif status == 2: status = 'REMOVED'
                elif status == 3: status = 'OVERWROTE'
                elif status == 4: status = 'APPENDED'
                elif status == 5: status = 'CLEARED'
                else: status = 'FAILED'

                f.write(f"\nTIME:{create_time} || STATUS:{status} || INFO: '{info}'\n")
                f.write(f'OP: {data[0]} # BCONTENT: {data[1]} # PERS: {data[2]} # FILE: "{data[3]}"\n\n')
            
            return True, 0
        
        elif optype == 'dirs':
            
            op_logfile = os.path.join(logs_path, 'operations.log')
            with open(op_logfile,'a+') as f:
                #TIME:STATUS:INFO
                #BCONTENT:PER:DIR_PATH
            
                if status == 1: status = 'CREATED'
                elif status == 2: status = 'REMOVED'
                elif status == 3: status = 'SET'
                elif status == 4: status = 'CLEARED'
                elif status == 5: status = 'EXTENDED'
                else: status = 'FAILED'

                f.write(f"\nTIME:{create_time} || STATUS:{status} || INFO: '{info}'\n")
                f.write(f'BCONTENT: {data[0]} # PERS: {data[1]} # FILE: "{data[2]}"\n\n')
            
            return True, 0
        else:
            return False, random.randint(142,440)
    
    class partitions:
        def __init__(self,dev):
            self.path = os.path.join(SATASelfInterface().devs, dev)
        
        def create(self):
            # EFI PART CHECK
            if not os.path.exists(os.path.join(self.path, 'root/media/EFI_x0915.sys')): self.EFI_MBR()
            
            #DISK-INFO COLLECT
            with open(os.path.join(self.path,'superblock.cfg'),'r+') as f:
                for line in f:
                    if line.startswith('DISK_SIZE='):
                        sizeof = int(line.strip().split('DISK_SIZE=')[1])
                    if line.startswith('pages_per_block='):
                        pages = int(line.strip().split('pages_per_block=')[1])
                        
            bsize = 0
            used_space = 0
            part_path = os.path.join(self.path, 'part')
            
            with open(os.path.join(part_path, 'part_table.meta'), 'r+') as f:
                for line in f:
                    if line.startswith('blocks:'):
                        use_space = float(line.strip().split('blocks:')[1])
                        used_space += use_space * pages * 4 # BLOCKS_SIZE -> MB
                        use_space = 0
                    if line.startswith('bsize:'):
                        bsize = line.strip().split('bsize:')[1]
                        bsize = bsize.split('-')
                        bsize = [int(x) for x in bsize]
            
            # MATH ...
            sizeof = sizeof/1024 # KB -> MB
            free_space = sizeof-used_space # MB
            min_space = (16*4096)/1024 # B -> MB
            
            #PRINT INFO
            print('== DISK | INFO ==')
            if sizeof > 1024: print(f'DISK size [MB]: {sizeof} | ~ {round((sizeof/1024),2)} [GB]')
            else: print(f'DISK size [MB]: {sizeof}')
            print(f'MIN. size [MB]: {min_space}')
            print(f'USED space [MB]: {used_space}')
            print(f'FREE space [MB]: {free_space}')

            #DATA COLLECT
            name = input('\nName: ')
            size = float(input('Size [MB]: '))
            if size > free_space:
                print('Operation failed')
                print('User entered more space than available!')
                SATASelfInterface.__logs__('part',0,['-','-','-',name,size],"ERROR SIZE")
                return
            
            if size < min_space:
                print('Operation failed')
                print('Not enaugh space to create partition!')
                SATASelfInterface.__logs__('part',0,['-','-','-',name,size],"ERROR SPACE")
                return
            
            if size == free_space:
                print('Operation freezed')
                print('Entered space equel available space!')
                check = input('Are you sure you want to continue? (Y/n): ')
                if check != 'Y':
                    print('Verification failed')
                    SATASelfInterface.__logs__('part',0,['-','-','-',name,size],"EQUEL VERIFICATION FAILED")
                    return
            
            fs = input('FileSystem: ')
            safe_lock = input('BBP (Y/n): ')
            mp = input('mount point: /')

            # SIZE, BLOCKS, BLOCKS-RANGE COUNTER
            size *= 1024 # MB -> KB
            blocks = size / 4096 # DIV PAGE SIZE
            blocks /= pages   # DIV PAGE_PER_BLOCK
            blocks = math.ceil(blocks)
            if bsize == 0:
                low = 0
            else:
                low = bsize[1]+1
            high = low+blocks-1
            blocks_range = [low,high]
            
            if safe_lock=='Y': BBP = blocks_range[1]-1
            else: BBP = '-'
            #LOGS, DATA CONTROL & WRITE -> FILES
            data_to_write = f'["{name}"]\nsize: {size*1024}\nbsize: {blocks_range[0]}-{blocks_range[1]}\nblocks: {blocks}\nfs: {fs}\nenc: -\nchecksum: -\nBBP: {BBP}\nmp: /{mp}\n!\n\n'
            with open(os.path.join(part_path, 'part_table.meta'), 'a+') as f:
                f.write(data_to_write)
            LOG, error = SATASelfInterface.__logs__(SATASelfInterface.partitions, 'part', 1, data=[fs,BBP,mp,name,size/1024], info="PARTITION CREATED", path=self.path)
            if LOG:
                print('\nCOMPLETED: Partition created succesfully\n')
            else:
                print(f'UNCOMPLETED: Partition failed during create process\nErrorCode: {error}\n')
        
        def remove_(self): ...
        def set_(self): ...
        def clear_(self): ...
        def EFI_MBR(self):
            #DISK-INFO COLLECT
            with open(os.path.join(self.path,'superblock.cfg'),'r+') as f:
                for line in f:
                    if line.startswith('DISK_SIZE='):
                        sizeof = int(line.strip().split('DISK_SIZE=')[1])
                    if line.startswith('pages_per_block='):
                        pages = int(line.strip().split('pages_per_block=')[1])
                        
            bsize = 0
            used_space = 0
            part_path = os.path.join(self.path, 'part')
            with open(os.path.join(part_path, 'part_table.meta'), 'r+') as f:
                for line in f:
                    if line.startswith('blocks:'):
                        use_space = float(line.strip().split('blocks:')[1])
                        used_space += use_space * pages * 4 # BLOCKS_SIZE -> MB
                        use_space = 0
                    if line.startswith('bsize:'):
                        bsize = line.strip().split('bsize:')[1]
                        bsize = bsize.split('-')
                        bsize = [int(x) for x in bsize]
            
            # MATH ...
            sizeof = sizeof/1024 # KB -> MB
            free_space = sizeof-used_space # MB
            min_space = (16*4096)/1024 # B -> MB
            
            #DATA COLLECT
            name = 'EFI'
            size = float(500)
            if size > free_space:
                print('Operation failed')
                print('SYSTEM reserver more space than available!')
                SATASelfInterface.__logs__('part',0,['-','-','-',name,size],"ERROR SIZE")
                return
            
            if size < min_space:
                print('Operation failed')
                print('Not enaugh space to create partition!')
                SATASelfInterface.__logs__('part',0,['-','-','-',name,size],"ERROR SPACE")
                return
            
            if size == free_space:
                print('Operation freezed')
                print('EFI Partition space equel available space!')
                check = input('Are you sure you want to continue? (Y/n): ')
                if check != 'Y':
                    print('Verification failed')
                    SATASelfInterface.__logs__('part',0,['-','-','-',name,size],"EQUEL VERIFICATION FAILED")
                    return
            
            fs = '-'
            safe_lock = '-'
            mp = 'root'

            # SIZE, BLOCKS, BLOCKS-RANGE COUNTER
            size *= 1024 # MB -> KB
            blocks = size / 4096 # DIV PAGE SIZE
            blocks /= pages   # DIV PAGE_PER_BLOCK
            blocks = math.ceil(blocks)
            if bsize == 0:
                low = 0
            else:
                low = bsize[1]+1
            high = low+blocks-1
            blocks_range = [low,high]
            
            if safe_lock=='Y': BBP = blocks_range[1]-1
            else: BBP = '-'
            
            #LOGS, DATA CONTROL & WRITE -> FILES
            data_to_write = f'["{name}"]\nsize: {size*1024}\nbsize: {blocks_range[0]}-{blocks_range[1]}\nblocks: {blocks}\nfs: {fs}\nenc: -\nchecksum: -\nBBP: {BBP}\nmp: /{mp}\n!\n\n'
            with open(os.path.join(part_path, 'part_table.meta'), 'a+') as f:
                f.write(data_to_write)
            LOG, error = SATASelfInterface.__logs__(SATASelfInterface.partitions, 'part', 3, data=[BBP,True,mp,name,size/1024], info="EFI CREATED", path=self.path)
            if LOG:
                print('\nCOMPLETED: EFI Partition created succesfully\n')
            else:
                print(f'UNCOMPLETED: EFI Partition failed during create process\nErrorCode: {error}\n')

            # CREATE EFI-SYS | POINTER-FILE
            with open(os.path.join(self.path, 'root/media', 'EFI_x0915.sys'),'w+') as f:
                f.write('SYS_BOOTLOADER_CFG_PATH=[/home/raw/Pulpit/PC/OS/syst/kernel/bootloader/boot.cfg]\n')
                f.write('SYS_BOOTLOADER_SCRIPT_PATH=[/home/raw/Pulpit/PC/OS/syst/kernel/bootloader/bootloader.py]\n')
            
    class files:
        def __init__(self, dev):
            self.fc = SATASelfInterface()
            self.path = os.path.join(SATASelfInterface().devs, dev)
            
        def read(self): ...
        
        def write(self):
            # COPY TEMP FOR CMD DEF RUN -> #?  mk filename.ext [-p/-ow/-a/-cl] (content) -p 110
            
            # COLLECT DATA
            part = input('part: ')
            cmd = input('> ')
            args = cmd.split()
            filename = args[1]
            op = args[2]
            
            #! FUNC CALLS
            if op == '-ow': #* call overwrite() function
                self.overwrite(cmd)
                return
            elif op == '-a': #* call append_() function
                self.append_(cmd)
                return
            elif op == '-cl': #* call clear_() function
                self.clear_(cmd)
            
            op_data = args[3]
            pers = args[4]
            pers_data = args[5]
            
            content = op_data.split('(')[1].split(')')[0]
            file_path = os.path.join(self.path, f'root/home/{filename}')
            
            # CHECK IF FILE EXISTS
            if os.path.exists(file_path): print("FILE ALREADY EXISTS"); exit()
            
            # FILE CREATE
            with open(file_path,'w+') as f:
                f.write(content)
                
            # INODE FILE SET
            file = '000'
            with open(self.fc.bitmap_inodes, 'r+') as f:
                inodes = f.read().splitlines()
                inode_numbers = []
                for inode in inodes:
                    try:
                        num = int(inode)
                        inode_numbers.append(num)
                    except IndexError: continue
                inode_numbers.sort()
                i = 0
                for num in inode_numbers:
                    if num != i: break
                    i += 1
                file = f'00{i}'
                
            with open(self.fc.bitmap_inodes, 'a+') as f:
                f.write(f'{file}\n')
            
            self.inode_path = os.path.join(self.fc.inodes, f'inode_{file}')
            with open(self.inode_path, 'w+') as f:
                f.write(f"size: {len(content)}\n")
                f.write(f"rwx-format: {pers_data}\n")
                f.write(f'pointer: 0\n')

            # PARTITONS
            with open(os.path.join(self.path, 'part/part_table.meta'),'r+') as f:
                correct = False
                for line in f:
                    if line.startswith(f'["{part}"]'):
                        correct = True
                        continue    
                    if correct:
                        if line.startswith('bsize:'):
                            blocks_range = line.strip().split('bsize:')[1]
                            blocks_range = blocks_range.strip().split('-')
                            blocks_range = [int(x) for x in blocks_range]
                            block = os.path.join(self.path,f'data/block_00{blocks_range[0]}')
                            break
                    if line == '!': correct = False
            
            # WRITE TO BLOCK x PAGE
            page = '000'
            with open(self.fc.bitmap_blocks, 'r+') as f:
                inodes = f.read().splitlines()
                inode_numbers = []
                for inode in inodes:
                    try:
                        num = int(inode.split('x')[1])
                        inode_numbers.append(num)
                    except IndexError: continue
                inode_numbers.sort()
                i = 0
                for num in inode_numbers:
                    if num != i: break
                    i += 1
                page = f'00{i}'
                                
            with open(self.fc.bitmap_blocks, 'a+') as f:
                f.write(f'0{blocks_range[0]}x{page}\n')
                
            with open(os.path.join(block,f'page_{page}'),'a+') as f:
                f.write(f'"{file_path}";("{content}")')
                inode_code = [blocks_range[0],i]
            
            # INODE FILE UPDATE
            with open(self.inode_path, 'w+') as f:
                f.write(f"size: {len(content)}\n")
                f.write(f"rwx-format: {pers_data}\n")
                f.write(f'pointer: 0x{inode_code[0]}0{inode_code[1]}\n')
                
            if content != None: bcontent=True
            else: bcontent=False    
            
            # CREATE VAR META-FILE
            
            #~ default values
            owner = '-' 
            parent = file_path.split('/')[-2]
            child = '-'
            SYS_PERS = 5 #^ 5 -> full permission
            obj_type = 'FILE'
            sys_parent = 'root'
            
            with open(os.path.join(self.fc.etc, f'{sys_parent}-{parent}-{filename.split(".")[0]}.var'), 'w+') as f:
                f.write(f"SYS_INODE:{file}\n")
                f.write(f"OWNER:{owner}\n")
                f.write(f"PARENT:{parent}\n")
                f.write(f"SYS_PARENT:{sys_parent}\n")
                f.write(f"CHILD:{child}\n")
                f.write(f"SYSTEM_PERMISSION_LEVEL:{SYS_PERS}\n")
                f.write(f"OBJECT_TYPE:{obj_type}\n")
            
            # LOGS
            LOG, error = self.fc.__logs__('operations', 1, [op,bcontent,pers_data,file_path], "CREATED", self.path)
            if LOG:
                print('\nCOMPLETED: File created succesfully')
            else:
                print(f'UNCOMPLETED: File failed during create process\nErrorCode: {error}')
        
        #! it need to be fixed cos of not the same index of page & inode - causing error
        def remove_(self):
            # COPY TEMP FOR CMD DEF RUN  #?  rm test2.txt -wc
            
            # COLLECT DATA
            cmd = input('> ').split()
            filename = cmd[1]
            mode = cmd[2]
            file_path = os.path.join(self.path, f'root/home/{filename}')
            
            # REMOVE FILE
            try: os.remove(file_path)
            except: print("Something went wrong during remove operation")
            
            # REMOVE VAR-META FILES
            inode = None
            #& default values
            sys_parent = 'root'
            parent = 'home'
            var_file = os.path.join(self.fc.etc, f'{sys_parent}-{parent}-{filename.split(".")[0]}.var')
            
            with open(var_file, 'r+') as f:
                for line in f:
                    if line.startswith("SYS_INODE:"):
                        inode = line.strip().split("SYS_INODE:")[1]
            
            if inode != None: os.remove(var_file)
            
            # REMOVE INODES PART
            with open(os.path.join(self.fc.inodes, f'inode_{inode}'), 'r+') as f:
                for line in f:
                    if line.startswith('rwx-format:'):
                        pers_data = line.strip().split('rwx-format:')[1]
                    if line.startswith('size:'):
                        bcontent = line.strip().split('size:')[1]
            with open(os.path.join(self.fc.inodes, f'inode_{inode}'), 'w+') as f: ...
            
            # REMOVE FROM BLOCK x PAGE            
            block = [x for x in inode][1]
            with open(os.path.join(self.fc.data, f'block_00{block}/page_{inode}'),'w+') as f: ...

            # REMOVE MAP PART
            with open(self.fc.bitmap_blocks, 'r+') as f:
                lines = f.readlines()
            address = f'00{block}x{inode}'
            updated_lines = []
            
            for line in lines:
                if line != address:
                    updated_lines.append(line)
                    
            with open(self.fc.bitmap_blocks, 'w+') as f:
                f.writelines(updated_lines)
            
            with open(self.fc.bitmap_inodes, 'r+') as f:
                lines = f.readlines()
            updated_lines = []
            
            for line in lines:
                if line != inode:
                    updated_lines.append(line)
                    
            with open(self.fc.bitmap_inodes, 'w+') as f:
                f.writelines(updated_lines)
        
            # LOGS
            LOG, error = self.fc.__logs__('operations', 2, [mode,bcontent,pers_data,file_path], 'REMOVED', self.path)
            if LOG:
                print('\nCOMPLETED: File removed succesfully')
            else:
                print(f'UNCOMPLETED: File failed during remove process\nErrorCode: {error}')
        
        def overwrite(self, cmd:str): 
            
            # COLLECT DATA
            args = cmd.split()
            filename = args[1]
            op = args[2]
            op_data = args[3] 
            content = op_data.split('(')[1].split(')')[0] #& data to overwrite
            file_path = os.path.join(self.path, f'root/home/{filename}')
            
            # CHECK IF FILE EXISTS
            exist_ = False
            if os.path.exists(file_path): exist_ = True
            else: print("FILE NOT EXISTS"); exit()
            
            # CREATE BACK-UP FILE IN VAR
            with open(file_path, 'r+') as f:
                lines = f.readlines()
            ow_cp_path = os.path.join(self.fc.vars, 'ow-bp_00x2')
            try: os.mkdir(ow_cp_path)
            except: ...
            with open(os.path.join(ow_cp_path, f'{filename}.bp'), 'w+') as f:
                f.writelines(lines)
                
            # DELETE OLD CONTENT
            with open(file_path, 'w+') as f: ...
            
            # WRITE NEW CONTENT
            with open(file_path, 'r+') as f:
                f.write(content)
                
            # LOGS
            LOG, error = self.fc.__logs__('operations', 3, [op,'-','-',file_path], 'OVERWROTE', self.path)
            if LOG:
                print('\nCOMPLETED: File overwrote succesfully')
            else:
                print(f'UNCOMPLETED: File failed during overwrite process\nErrorCode: {error}')
            
        def append_(self, cmd:str):
            # COLLECT DATA
            args = cmd.split()
            filename = args[1]
            op = args[2]
            op_data = args[3]
            content = op_data.split('(')[1].split(')')[0] #& data to append
            file_path = os.path.join(self.path, f'root/home/{filename}')
            
            # CHECK IF FILE EXISTS
            exist_ = False
            if os.path.exists(file_path): exist_ = True
            else: print("FILE NOT EXISTS"); exit()
            
            # CREATE BACK-UP FILE IN VAR
            with open(file_path, 'r+') as f:
                lines = f.readlines()
            ap_cp_path = os.path.join(self.fc.vars, 'ap-bp_00x2')
            try: os.mkdir(ap_cp_path)
            except: ...
            with open(os.path.join(ap_cp_path, f'{filename}.bp'), 'w+') as f:
                f.writelines(lines)
            
            # DELETE OLD CONTENT
            with open(file_path, 'w+') as f: ...
            
            # WRITE NEW CONTENT
            lines.append('\n')
            lines.append(content)
            with open(file_path, 'r+') as f:
                f.writelines(lines)
            
            # LOGS
            LOG, error = self.fc.__logs__('operations', 4, [op,'-','-',file_path], 'APPEND', self.path)
            if LOG:
                print('\nCOMPLETED: File updated succesfully')
            else:
                print(f'UNCOMPLETED: File failed during update process\nErrorCode: {error}')
            
        def clear_(self, cmd:str):
            
            # COLLECT DATA
            args = cmd.split()
            filename = args[1]
            op = args[2]
            file_path = os.path.join(self.path, f'root/home/{filename}')
            
            # CHECK IF FILE EXISTS
            exist_ = False
            if os.path.exists(file_path): exist_ = True
            else: print("FILE NOT EXISTS"); exit()
            
            # CREATE BACK-UP FILE IN VAR
            with open(file_path, 'r+') as f:
                lines = f.readlines()
            ap_cp_path = os.path.join(self.fc.vars, 'cl-bp_00x2')
            try: os.mkdir(ap_cp_path)
            except: ...
            with open(os.path.join(ap_cp_path, f'{filename}.bp'), 'w+') as f:
                f.writelines(lines)
                
            # CLEAR OLD FILE CONTENT
            with open(file_path, 'w+') as f: ...
            
            # LOGS
            LOG, error = self.fc.__logs__('operations', 5, [op,'-','-',file_path], 'CLEAR', self.path)
            if LOG:
                print('\nCOMPLETED: File cleared succesfully')
            else:
                print(f'UNCOMPLETED: File failed during clear process\nErrorCode: {error}')
            
        def set_(self): ...

        class _SYSFILES_:
            def __init__(self): ...
            def sata_conn_file_C():
                try:
                    with open(r"/home/raw/Pulpit/PC/OS/pt/SATA/conn_file.cfg", 'w+') as f: ...
                    return True
                except: return False
            def sata_conn_file_R():
                return r"/home/raw/Pulpit/PC/OS/pt/SATA/conn_file.cfg"
    
    class dirs:
        def __init__(self):
            self.fc = SATASelfInterface()
            
        def create(self):
            # COPY TEMP FOR CMD DEF RUN -> #? mkdir dirname -p 111
            
            # COLLECT DATA
            part = input('part: ')
            cmd = input('> ')
            args = cmd.split()
            dirname = args[1]
            pers = args[2]
            pers_data = args[3]
            dir_path = os.path.join(self.fc.path, f'root/home/{dirname}')
            
            # CHECK IF DIR EXISTS
            if os.path.exists(dir_path): print("DIR ALREADY EXISTS"); exit()
            
            # DIR CREATE
            os.makedirs(dir_path)
            bcontent = '-'
            c = []
            for obj in os.listdir(dir_path):
                c.append(obj)
            if len(c) > 0:
                bcontent = len(c)
                
            # INODE FILE SET
            file = '000'
            with open(self.fc.bitmap_inodes, 'r+') as f:
                inodes = f.read().splitlines()
                inode_numbers = []
                for inode in inodes:
                    try:
                        num = int(inode)
                        inode_numbers.append(num)
                    except IndexError: continue
                inode_numbers.sort()
                i = 0
                for num in inode_numbers:
                    if num != i: break
                    i += 1
                file = f'00{i}'
                
            with open(self.fc.bitmap_inodes, 'a+') as f:
                f.write(f'{file}\n')
            
            self.inode_path = os.path.join(self.fc.inodes, f'inode_{file}')
            with open(self.inode_path, 'w+') as f:
                f.write(f"size: {bcontent}\n")
                f.write(f"rwx-format: {pers_data}\n")

            # PARTITONS
            with open(os.path.join(self.fc.path, 'part/part_table.meta'),'r+') as f:
                correct = False
                for line in f:
                    if line.startswith(f'["{part}"]'):
                        correct = True
                        continue    
                    if correct:
                        if line.startswith('bsize:'):
                            blocks_range = line.strip().split('bsize:')[1]
                            blocks_range = blocks_range.strip().split('-')
                            blocks_range = [int(x) for x in blocks_range]
                            block = os.path.join(self.fc.path,f'data/block_00{blocks_range[0]}')
                            break
                    if line == '!': correct = False
            
            # WRITE TO BLOCK x PAGE
            page = '000'
            with open(self.fc.bitmap_blocks, 'r+') as f:
                inodes = f.read().splitlines()
                inode_numbers = []
                for inode in inodes:
                    try:
                        num = int(inode.split('x')[1])
                        inode_numbers.append(num)
                    except IndexError: continue
                inode_numbers.sort()
                i = 0
                for num in inode_numbers:
                    if num != i: break
                    i += 1
                page = f'00{i}'
                                
            with open(self.fc.bitmap_blocks, 'a+') as f:
                f.write(f'0{blocks_range[0]}x{page}\n')
                
            with open(os.path.join(block,f'page_{page}'),'a+') as f:
                f.write(f'"{dir_path}"')
                inode_code = [blocks_range[0],i]
            
            # INODE FILE UPDATE
            with open(self.inode_path, 'a+') as f:
                f.write(f'pointer: 0x{inode_code[0]}0{inode_code[1]}\n')
            
            # CREATE CFG FILE IN ETC
            #~ default values
            owner = '-'
            parent = dir_path.split('/')[-2]
            child = '-'
            SYS_PERS = 5 #^ 5 -> full permission
            obj_type = 'DIR'
            sys_parent = 'root'
            
            #& that cfg-file is only part - there will be bigger separated module for that
            dir_cfg_data_to_write_ = [
                "## Uncomment 1 '#' if setting line is needed",
                "## Do not uncomment lines with '##' at start - only with info!",
                ""*4,
                "   ## SELF ##",
                f"OBJ_META_DATA=[{inode},{dir_path},{pers_data},{bcontent}]",
                "#DIR_ASM_EXECUTE_ACCESS=True",
                "#DIR_BOOT_ACCESS=True",
                "#DIR_BOOT_MODE=[1;5]",
                "DIR_DEEP_ACCESS_BLOCK=31",
                "OBJ_TYPES=[**]",
                ""*2,
                "   ## MORE ##",
                "#ENC_MAX_LEVELS=[**!{1,5}]",
                "## '!' mean without",
                "ENC_MAX_KEY_LEN=[>key&shift<]",
                "#ZIP_MAX_SHORT=",
                "#ZIP_MODES=[**]",
                "ALL_META_DATA_VISABLE=False",
                ""*2,
                "   ## NETWORK ##",
                "#ENABLE_CMP_NET_CFG_FILES=True",
                "#ENABLE_CFG_ARP_MAP_FILE=True",
                "#ENABLE_SERVER_CONN=True",
                "#ENABLE_EM_SERVER_BP_POINT=True,[5]",
                "## [5] mean after 5 cycles folder need to be empty",
                "IP_MAC_MAPING=True",
            ]
            
            dir_cfg_path = os.path.join(self.fc.etc, 'dir-cfg_00x1')
            try: os.mkdir(dir_cfg_path)
            except: ... 
            with open(os.path.join(dir_cfg_path, f'{sys_parent}_{parent}-{dirname}.cfg'), 'w+') as f:
                for cfg_data in dir_cfg_data_to_write_:
                    f.write(f"{cfg_data}\n")
            
            # CREATE VAR META-FILE
            with open(os.path.join(self.fc.vars, f'{sys_parent}-{parent}-{dirname.split(".")[0]}.var'), 'w+') as f:
                f.write(f"SYS_INODE:{file}\n")
                f.write(f"OWNER:{owner}\n")
                f.write(f"PARENT:{parent}\n")
                f.write(f"SYS_PARENT:{sys_parent}\n")
                f.write(f"CHILD:{child}\n")
                f.write(f"SYSTEM_PERMISSION_LEVEL:{SYS_PERS}\n")
                f.write(f"OBJECT_TYPE:{obj_type}\n")
            
            # LOGS
            LOG, error = self.fc.__logs__('dirs', 1, [bcontent, pers_data, dir_path], "CREATED", self.fc.path)
            if LOG:
                print('\nCOMPLETED: Dir created succesfully')
            else:
                print(f'UNCOMPLETED: Dir failed during create process\nErrorCode: {error}')

        def remove_(self):
            # COPY TEMP FOR CMD DEF RUN  #?  rmdir test2.txt -wc
            
            # COLLECT DATA
            cmd = input('> ').split()
            dirname = cmd[1]
            mode = cmd[2]
            dir_path = os.path.join(self.fc.path, f'root/home/{dirname}')
            
            # REMOVE DIR
            try: os.remove(dir_path)
            except: print("Something went wrong during remove operation")
            
            # REMOVE CFG FILE IN ETC
            #~ default values
            parent = dir_path.split('/')[-2]
            sys_parent = 'root'
            
            dir_cfg_path = os.path.join(self.fc.etc, 'dir-cfg_00x1')
            try: os.mkdir(dir_cfg_path)
            except: ... 
            os.rmdir(os.path.join(dir_cfg_path, f'{sys_parent}_{parent}-{dirname}.cfg'))
            
            # REMOVE VAR-META FILES
            inode = None
            #& default values
            sys_parent = 'root'
            parent = 'home'
            var_file = os.path.join(self.fc.etc, f'{sys_parent}-{parent}-{dirname.split(".")[0]}.var')
            
            with open(var_file, 'r+') as f:
                for line in f:
                    if line.startswith("SYS_INODE:"):
                        inode = line.strip().split("SYS_INODE:")[1]
            
            if inode != None: os.remove(var_file)
            
            # REMOVE INODES PART
            with open(os.path.join(self.fc.inodes, f'inode_{inode}'), 'r+') as f:
                for line in f:
                    if line.startswith('rwx-format:'):
                        pers_data = line.strip().split('rwx-format:')[1]
                    if line.startswith('size:'):
                        bcontent = line.strip().split('size:')[1]
            with open(os.path.join(self.fc.inodes, f'inode_{inode}'), 'w+') as f: ...
            
            # REMOVE FROM BLOCK x PAGE            
            block = [x for x in inode][1]
            with open(os.path.join(self.fc.data, f'block_00{block}/page_{inode}'),'w+') as f: ...

            # REMOVE MAP PART
            with open(self.fc.bitmap_blocks, 'r+') as f:
                lines = f.readlines()
            address = f'00{block}x{inode}'
            updated_lines = []
            
            for line in lines:
                if line != address:
                    updated_lines.append(line)
                    
            with open(self.fc.bitmap_blocks, 'w+') as f:
                f.writelines(updated_lines)
            
            with open(self.fc.bitmap_inodes, 'r+') as f:
                lines = f.readlines()
            updated_lines = []
            
            for line in lines:
                if line != inode:
                    updated_lines.append(line)
                    
            with open(self.fc.bitmap_inodes, 'w+') as f:
                f.writelines(updated_lines)
        
            # LOGS
            LOG, error = self.fc.__logs__('dirs', 2, [bcontent, pers_data, dir_path], "CREATED", self.fc.path)
            if LOG:
                print('\nCOMPLETED: Dir removed succesfully')
            else:
                print(f'UNCOMPLETED: Dir failed during remove process\nErrorCode: {error}')
                
        def set_(self): ...
        
        def clear_(self):
            # COPY TEMP FOR CMD DEF RUN  #?  cleardir test2.txt
            
            # COLLECT DATA
            cmd = input('> ').split()
            dirname = cmd[1]
            dir_path = os.path.join(self.fc.path, f'root/home/{dirname}')
            
            # CLEAR DIR
            try:
                for item in os.listdir(dir_path):
                    
                    if os.path.isdir(item): 
                        try: self.fc.files.remove_(self.fc.files(self.fc.disk))
                        except: os.rmdir(item)
                        
                    elif os.path.isfile(item):
                        try: self.fc.files.remove_(self.fc.files(self.fc.disk))
                        except: os.rmdir(item)
                          
            except: print("Something went wrong during clear operation")
            
            # LOGS
            LOG, error = self.fc.__logs__('dirs', 4, ['-', '-', dir_path], "CLEARED", self.fc.path)
            if LOG: 
                print('\nCOMPLETED: Dir cleared succesfully')
            else: 
                print(f'UNCOMPLETED: Dir failed during clear process\nErrorCode: {error}')
                
        def extend_(self): ...
    
    def list_(self): ...
    
    #todo   add send-function logic
    #&  more vars, options
    class transfers:
        def __init__(self):
            self.actual_transfer = 0 #* without taffic
            self.actual_unit = "B" #* default
            
            #^ IN BYTES
            self.READ_SPEED_MAX = 52
            self.WRITE_SPEED_MAX = 33
            self.READ_SPEED_MIN = 15
            self.WRITE_SPEED_MIN = 6
            
            #^ IN SECONDS
            self.READ_TICK = 3
            self.WRITE_TICK = 5
            
            self.UNITS = ["B", "KB", "MB"]
            
        def calc_(self, fullsize, type, unit, src, dst):
            if not unit in self.UNITS:
                print()
                time.sleep()
                exit()
            
            if unit == "KB":
                fullsize *= 1024
            elif unit == "MB":
                fullsize *= 1024 * 1024
                
            if type == 'READ':
                n = random.uniform(0.51, 0.84)
                time_ = f"{((fullsize / random.randrange(self.READ_SPEED_MIN, self.READ_SPEED_MAX)) * (self.READ_TICK / n)):.6f}"

            self.parts = [digit + " " if digit.isdigit() else "- " for digit in time_]
            return ''.join(self.parts)
        def send_(self, src, dst): ...
        def get_transfer(self): ...
        def set_transfer(self): ...
        def test_transfer(self): ...
    
    def power_management(self): ...
    class command_base: ... 
class SATASelfController: ...
class SATASelfOperations: ...
class SATAConfigProgramsPack: ...
class SATAToolsAndUtils: ...
class SATAKernelConnection: ...
class SATADriversConnection: ...
class SATASelfIOInterrupts: ...
class SATABiosConnection: ...
class SATAFileSystemMode: ...
class SATAFileSystemConnection: ...
class SATAFileSystemResult: ...
class SATASelfRun: ...

#^ SPECIAL MODULES
class SATATestConnectionStatus: ...
class SATATestKernelStatus: ...
class SATATestInterfaceOperations: ...
class SATATestAll: ...
class SATAHelp: ...

# INTERFACE LAUNCH
class SATA:
    def __init__(self):
        self.hardware = SATAHardwareLogicConnection()
        self.IO = SATASelfIOInterrupts()
        
        self.interface = SATASelfInterface()
        self.controller = SATASelfController()
        self.operations = SATASelfOperations()
        
        self.config_pack = SATAConfigProgramsPack()
        self.tools = SATAToolsAndUtils()
        
        self.kernel_conn = SATAKernelConnection()
        self.drivers = SATADriversConnection()
        self.bios = SATABiosConnection()
        
        self.fs_mode = SATAFileSystemMode()
        self.fs_conn = SATAFileSystemConnection()
        self.fs_result = SATAFileSystemResult()
        
        self.conn_status = SATATestConnectionStatus(),
        self.kernel_status = SATATestKernelStatus(),
        self.interface_ops = SATATestInterfaceOperations(),
        self.all_ = SATATestAll()

        self.RUN = SATASelfRun()
        self.help = SATAHelp()
    
    def main(self):
        self.RUN
        self.interface.transfers.calc_(self.interface.transfers(),50,"READ","MB","/","../")
        self.interface.files.write(self.interface.files(dev='C'))
        self.interface.files.remove_(self.interface.files(dev='C'))
        self.interface.dirs.create(self.interface.dirs())
        self.interface.partitions.create(self.interface.partitions('C'))
        ...
    
#?  main show off for SATA module 
if __name__ == "__main__":
    #sata = SATA()
    #sata.main()
    ...
