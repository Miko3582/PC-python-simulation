"""Hardware USB Port Handler\n
- - -
Layers for:
- communcation
- interrupts
- enumerating
- transfer
- memory management
- endpoints
- debuging
- user-space conn

- - -
`h` - handler\n
`tr` - transfer\n
`ir`- interrupt\n
`iso` - isochronous\n
`ept` - endpoint 
"""

# SETTINGS

p_file = r"/home/raw/Pulpit/PC/MOTHERBOARD/PORTS/lnhdr"
p_listen = False

p_dpp = None
p_dmn = 0
p_gnd = 0


# MAIN FUNCTIONS

# communcation
def usb_reg_driver(): ...
def usb_unreg_driver(): ...
    
# interrupts
def usb_ir_h(): ...
def usb_h_event(): ...

# enumerating
def usb_enum(): ...
def usb_get_descriptor(): ...
def usb_addr_dev(): ...

# transfer
def usb_bulk_tr(): ...
def usb_ir_tr(): ...
def usb_iso_tr(): ...

# memory management
def usb_alloc_buff(): ...
def usb_free_buff(): ...

# endpoints
def usb_setup_ept(): ...
def usb_rm_ept(): ...

# debuging
def usb_dbg(): ...
def usb_log_event(): ...

# user-space conn
def usb_create_dev(): ...
def usb_rm_dev(): ...

# control
def listener():

    while p_listen:
        lines = []
        with open(p_file, "r+") as f:
            for line in f:
                lines.append(int(line.strip().split('=')[1]))
                a = 0b00100000-0b0000001
                
        # detect dev pluged in to port [pins method]
        if (lines[1] != p_dmn) & (lines[2] != p_dpp) & (lines[0] == 0b0001011):
            dev_type = "USB"
            return True, dev_type
