
#! MENU FOR BIOS-UEFI

# imports
import time,os,random,sys
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '../../../')))

from OS.syst.kernel.bootloader.bootloader import DEV_SCRIPT_RUNNER as SCR, DEV_MENUS_SCANNER as MNS, DEV_ISO_RUNNER as ISO

#UEFI implementation
class UEFI: ...

# BIOS implementation
class BIOS:
    
    # GRUB DATA STORAGE
    def __init__(self) -> None:
        self._POST_ = False
        self.devs_path = r'/home/raw/Pulpit/PC/OS/dev'
        self.POST_LIST = ['CPU','RAM','BUS','STORAGE','I/O','OTHER']
        
        self.devs = []
        self.bootable_devs = {}
        self.more_bootable_devs = []
        self.boot_types = []
        
        self.dev_high = 0
        self.queue = ["SSD", "USB", "CD/DVD"]
    
    # MAIN MODULES
    def load_bootloader(self):
        for dev, pack in self.bootable_devs.items():
            boot_file, name = pack
            
            BOOT = os.path.join(self.devs_path, dev, boot_file)

            with open(BOOT, 'r+') as f:
                for line in f:
                    if line.startswith('type='):
                        boot_type = line.strip().split('type=')[1]
                        if boot_type in self.queue:
                            self.boot_types.append(boot_type)
                            dev_lv = self.queue.index(boot_type)
                            if self.dev_high < dev_lv:
                                self.dev_high = dev_lv
                            
                            if self.dev_high == dev_lv:
                                self.more_bootable_devs.append([dev, name])
                                self.dev_high = -2
                                
        if self.dev_high > -1:
            time.sleep(3)
            os.system('clear')
            print('BOOT DEV FOUNDED')
            print(f'RUNNING: {dev}')
            time.sleep(2)
            os.system('clear')
        
        if self.dev_high == -2:
            dev_to_boot_list = [] #& cretead cos of bug in line ...\63 - [IF STATEMENT; after input]
            time.sleep(3)
            os.system('clear')
            print('FOUNDED MORE THAN 1 BOOTABLE DEV:')
            
            for i, pack in enumerate(self.more_bootable_devs,start=1):
                dev, name = pack
                print(f'{i}: {dev}\t-> [{self.boot_types[i-1]}][{name}]')
                dev_to_boot_list.append(dev)
            dev_to_boot = input('DEV PORT/INTERFACE: ')
            
            if dev_to_boot in dev_to_boot_list:
                print(f'RUNNING: {dev_to_boot}')
                time.sleep(2)
                os.system('clear')
                dev_path = os.path.join(self.devs_path, dev_to_boot)
                
                #^ SCRIPTS SCAN
                scripts_path = os.path.join(dev_path, 'root/etc/scripts')
                scripts_founded = ''
                try: 
                    if len(os.listdir(scripts_path)) >= 1:
                        scripts_founded = '/root/.../*'
                except: ...
                
                #^ EFI SCAN
                menus_content = '*EFI_x0915'
                EFI_ = os.path.join(dev_path, 'root/media/EFI_x0915.sys')
                if not os.path.exists(EFI_):
                    menus_content = ''
                    print("EFI partition not found!")
                    
                #^ ISO SCAN
                iso_name = ''
                ISO_ = os.path.join(dev_path, '.BOOT')
                if os.path.exists(ISO_):
                    for item in os.listdir(ISO_):
                        if item.startswith('system_'):
                            iso_name = item
                if iso_name == '':
                    print("ISO pack not found!")

                choice = int(input(f"1. Run srcipt [{scripts_founded}]\n2. ISO [{iso_name}]\n3. Menus [{menus_content}]\n4. Exit\n> "))
                time.sleep(2)
                os.system('clear')
                
                if choice == 1: SCR.scanner(SCR(dev_to_boot))
                elif choice == 2: 
                    if ISO_ != '': 
                        ISO.run(ISO_)
                        exit()
                    else: 
                        print("Fix it and try again!")
                        time.sleep(2)
                        BIOS().main()
                    
                elif choice == 3: MNS
                elif choice == 4: time.sleep(2); exit()
                
            else:
                print('DEV NOT FOUND')
                time.sleep(1)
                os.system('clear')
                self.more_bootable_devs.clear()
                self.load_bootloader()
                
    def POST(self):
        time.sleep(1)
        for item in self.POST_LIST:
            print(f'{item}: READY')
            time.sleep(random.uniform(0.1,0.5))
        self._POST_ = True
        os.system('clear')
        
    def dev_scan(self):
        for devs in os.listdir(self.devs_path):
            dev = os.path.join(self.devs_path, devs)
            if not os.path.isdir(dev): print('FOUNDED NOT-DEV OBJECT: 0x0000010A ^ -adr $ 0xA15B400F')
            else: self.devs.append(devs)
            time.sleep(random.uniform(0.6, 1))
        os.system('clear')
            
    def dev_bootable(self):
        
        for dev in self.devs:
            dev_path = os.path.join(self.devs_path, dev)
            for item in os.listdir(dev_path):
                if item == 'boot':
                    with open(os.path.join(dev_path, item, 'grub.cfg'), 'r+') as f:
                        for line in f:
                            if line.startswith("Product="):
                                dev_name = str(line.strip().split('Product=')[1])
                    self.bootable_devs[dev] = ['boot/boot.img', dev_name]
                    time.sleep(1)
                if item == 'usbcore.d':
                    with open(os.path.join(dev_path, item), 'r+') as f:
                        for line in f:
                            if line.startswith("Product="):
                                dev_name = str(line.strip().split('Product=')[1])
                                
                if item == 'boot.img':
                    self.bootable_devs[dev] = ['boot.img', dev_name]
                    time.sleep(0.5)
                    
        print(f'FOUNDED BOOT DEVICES:')
        for dev, pack, in self.bootable_devs.items():
            _, name = pack
            print(f"    -[{dev}]\t***    [-generic --version -m -old] <{name}>")
            time.sleep(random.uniform(0.6, 3.5))
            
    # GRUB CONSOLE
    def console(self): ...
            
    # MAIN BIOS RUN
    def main(s): 
        os.system('clear')
        print("""You see this because of: \n-Not Operating System founded.\nReboot now or try to boot from device.\nFor more help run `HELP` or enter Console\n""")
        print('BIOS CONSOLE')
        print('1. BIOS - [Start]')
        print('2. Console')
        print('3. Settings')
        print('4. Help')
        print('5. Exit')
        choice = input('> ')
            
        if choice == '1':
            s.POST()
            
            if not s._POST_: 
                print('POST ERROR ; BREAKING')
                time.sleep(2); exit()
                
            s.dev_scan()
            s.dev_bootable()
            s.load_bootloader()
            time.sleep(1.8)
            print('Done')
            
        elif choice == '2': s.console()
        elif choice == '3': ...
        elif choice == '4': ...
        elif choice == '5': print('Exiting ...'); exit()
        else: print('Option not found'); exit()
        
if __name__ == '__main__':
    bios = BIOS()
    bios.main()
