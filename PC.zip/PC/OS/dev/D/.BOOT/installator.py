import sys, time, os, random

class INSTALLATOR:
    
    def __init__(self): 
        self.path = r'/home/raw/Pulpit/PC/OS/dev/D/.BOOT'
        
        self.title = "OS Installator"
        self.version = '1.0.901.2735.260'
        self.iso = 'system_519_module_.iso'
        self.mode = [1,4]
        
    def shutdown(self): exit()
    
    def questions(self):
        print("\n\n---== SETTING ==---\n")
        time.sleep(1)
        
        answers = []
        
        host = input("HOSTNAME: ")
        answers.append(host)
        
        pwd = input("Password: ")
        answers.append(pwd)
        
        pwdr = input("Repeat password: ")
        answers.append(pwdr)
        
        NET = input("Config NET? (Y/n) ")
        answers.append(NET)
        
        fs = input("FileSystem: ")
        answers.append(fs)
        
        mount = input("Mount: /")
        answers.append(mount)
        
        swap = input("SWAP needed? (Y/n) ")
        answers.append(swap)
        
        timeout = input("GRUB_TIMEOUT [s]: ")
        answers.append(timeout)
        
        LOG_LV = input("LOG Level [1-5]: ")
        answers.append(LOG_LV)
        
        drivers_load = input("Load drivers? (Y/n) ")
        answers.append(drivers_load)
        
        
        for answer in answers:
            if str(answer).upper() == 'Y':
                answer = True
            if str(answer).lower() == 'n':
                answer = False
        self.data = answers
        
    def config_img(self):
        questions = [
            "HOSTNAME",
            "PWD",
            "RPWD",
            "NET CFG",
            "FS",
            "MOUNT",
            "SWAP",
            "GRUB_TIMEOUT",
            "LOG_LV",
            "DRVIERS_LOAD",
        ]
        
        print("\n\n---== CONFIGURATING FILES ==---\n")
        time.sleep(7)
        print('Completed!')
        print("Your settings:")
        for k, v in zip(questions, self.data):
            print(f"{k}: {v}")
        input("Enter to continue ")
        time.sleep(2)
        
    def installing(self):
        os.system('clear')
        print(print("---== INSTALLING ==---\n"))
        time.sleep(5)
        os.system('clear')
        
        for i in range(100):
            print(f"Installing - {i}%")
            time.sleep(random.uniform(0.1, 0.6))
            os.system('clear')
            
        print("\nInstallation complete")
        print("Remove ISO device and reboot!\n")
        input('.')
        
    def copying_img(self): ...

    def run(self):
        print(self.title)
        print(f"ver: {self.version}")
        print(f"file: {self.iso}")
        print(f"mode={self.mode[0]}")
        print(f"lv={self.mode[1]}")        
        
        time.sleep(3)
        os.system('clear')
        
        self.questions()
        self.config_img()
        self.installing()
        self.copying_img()
    
if __name__ == "__main__":
    funct = sys.argv[1]
    if funct == 'run':
        time.sleep(3.5)
        INSTALLATOR().run()
    elif funct == 'exit':
        time.sleep(2)
        INSTALLATOR().shutdown()