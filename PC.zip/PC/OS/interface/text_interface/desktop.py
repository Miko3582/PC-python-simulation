import sys


prefixes = [
    '>',
    '>>',
    '$',
    '<path>$',
    '<path>>',
    'shell$>',
    '<DEV>:<path>$',
    '<DEV>:<path>>',
]

def input_stream(prefix='', suffix='', breakpoint=None):
    ...
    
def display_msg(msg, mode=0, offset=0, prefix='', suffix='', breakpoint=None):
    stdout = []
    for char in (prefix+msg+suffix):
        if char == breakpoint: break
        stdout.append(str(char))
    stdout = ''.join(stdout)
    print(f"{' ' * offset}{stdout}")
    
#display_msg("test",offset=1,suffix='2',breakpoint='2')