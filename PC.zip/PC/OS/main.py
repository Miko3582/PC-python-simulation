import sys, os, pynput
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '../')))
import OS.syst.kernel.core.ALL as _

item = ""
input_r = _.__KERNEL__().interrupts.INPUT(buff_size=16, running=True, cleared=True)
input_r.keys_queue.put(item=item)
input_r.press_flag(is_pressed=True, timeout=1)
input_r.curr_key = item
input_r.pressed = True
input_r.dispacher_()