# Extensions Controller Module

import time,os,random

class TXT:
    """
    .txt -> Default extension for text notes.\n
    User-friendly extension created for making notes and storing own informations.\n
    * EXTENSION FORMAT -> .txt
    * EXTENSION SYNTAX -> N/A
    """
    def __init__(self) -> None:
        self.name = 'txt'
        self.v = '1.0.2'
        self.note = 'u-f notes'
        
    def initialize(fpath:str,per,enc,op):
        check_per = TXT.Tools.getper(per)
        check_enc = TXT.Tools.getenc(enc)
        
        if (check_enc or check_per) == False:
            print('Authorization failed.')
            return NotImplemented
        
        file = fpath.split('/')[-1]
        cpath = r'/home/raw/Pulpit/PC/OS/syst/modules_cfg_files/FILES.ini'
        file_data = []
        with open(cpath,'r+') as cf:
            for line in cf:
                if line.startswith(file):
                    file_data = line.split(file)[1:]
                    file_data = ''.join(file_data)
                    break
                
        if len(list) < 4:
            print('FileDataRead operation failed.')
        
    def load(self):
        pass
    
    def unload(self):
        pass
    
    class Tools:
        
        def getper(x):
            pass
        
        def getenc(x):
            pass
        
        
        
