import time,os,random
from ..sec.pers import LXSP01 as _LXSP01
from ..shell.references.errors import SCM as _SCM_
os.system('clear')
_LXSP01_key=None
_LXSP01_value=None
if _LXSP01:
    _LXSP01_key='LXSP01'
    _LXSP01_value=_LXSP01
    #print(f'{_LXSP01_key}={_LXSP01_value}')
boot_path = r'/home/raw/Pulpit/PC/OS/BOOT/boot_file_1.cfg'
#grub_path = r''
drivers_path = r'/home/raw/Pulpit/PC/OS/syst/lib/drivers/driv_file_1.cfg'
#controllers_path = r''
kernel_path = r'/home/raw/Pulpit/PC/OS/syst/kernel/kernel_file_1.cfg'

def boot_cfg():
    no_error = True
    settings = ["_sys_conn_=","default=","timeout=","show_more=","ufi="]
    
    with open(boot_path,'r+') as boot_file:
        for line in boot_file:
            if line.startswith('_sys_='):
                sys_key = line.strip().split('_sys_=')[1].capitalize()
                if sys_key == 'True':
                    print(f'SYS_KEY_STATUS={sys_key}')
            elif not line.startswith('_sys_='):
                continue
            else:
                no_error = False
                _SCM_.bf_ERROR()
                return
                 
    with open(boot_path,'r+') as boot_file:
        for line in boot_file:
            for setting in settings:
                if line.startswith(setting):
                    val = line.strip().split(setting)[1]
                    if isinstance(val, str):
                        val = val.capitalize()
                    #print(f'{setting}{val}')
                elif not line.startswith(setting):
                    continue
                else:
                    no_error = False
                    _SCM_.bf_ERROR()
                    
                    
# check file -> 'boot_file_1.cfg'
#boot_cfg()