# Special Permission Adapter

class DA_LX36():
    """
    Drivers Config Special Permission Module.\n\n
    Example format for LX-36:\n
    '$$1-75^011;:%0x0140!rx1{g-cp}/L!1'\n
    - $$: - len(2) czyli .ini; 1-75 - kompatybilność z @CFE; dokładnie: ASNA_75
    - ^001;; - r-w-x; ";:" - obsluga błędów, brak obsługi kodowania
    - %0x0140 - adres RAM
    - !rx1 - rejestr operacji, 1 - timeout
    - {g-cp} - flagi: --g, --cp ;(get - auto pobieranie klucza, cp - porównuje z sygnałem)
    - / - oryginalność
    - L!1 - obsługa logów
    """
    def __init__(self) -> None: ...
    
    def _CONF_(self) -> list:
        DATA_OBJ = [self.file_format,self.ENC,self.rwx,self.RAM_ADRESS,self._ARGS_,self._LOGS_STATUS]
        return DATA_OBJ
    
    def collect_data(self,data:str,request:bool,format:int,_REG_:list[str]):
        self.MODULE,self.PER,self.PER_FORMAT,self.prefix = "DA","LX-36",data,'0x'
        if request != False: exit()
        self.request = request
        self.timeout = _REG_[1]
        self.val = _REG_[0]
        if _REG_[0] == 'rx': self.REG_STATUS = True
        else: self.REG_STATUS = False
        if format == 1: self.__LX36__()
        
    def __LX36__(self):
        data = self.PER_FORMAT
        file_format = data.split("^")[0]
        file_format, ENC = file_format.rsplit("$")
        if len(file_format) == 1: self.file_format = '.cfg'
        elif len(file_format) == 2: self.file_format = '.ini'
        else: exit()
        enc_format, enc_val = ENC.split('-')
        self.ENC = [enc_format, enc_val]
        rwx = data.split("^")[1].split('%')[0]
        try: _ERRORS_ =  rwx.index(';');_ERRORS_ = True
        except: _ERRORS_ = False
        try: ENC_STATUS =  rwx.index(';');ENC_STATUS = True
        except: ENC_STATUS = False
        self.rwx = rwx.split()[-2]
        self.RAM_ADRESS = data.split('%')[1].split('!')[0]
        if not self.prefix in self.RAM_ADRESS: exit()
        REG = data.split("!")[1].split("{")[0]
        if not REG == f"{self.val}{self.timeout}": exit()
        args = data.split("{")[1].split('}')[0]
        if args != None: self._ARGS_ = args.split('-')
        if not '/' in data: exit() # ... not for real system shutdown
        self._LOGS_STATUS = data.split('/')[1:]
        if self._LOGS_STATUS[-1] == '1': self._LOGS_STATUS = True
        elif self._LOGS_STATUS[:-1] == '0': self._LOGS_STATUS = False
        else: exit() # for test
        self.request:bool = True
        return self.request
    
    
