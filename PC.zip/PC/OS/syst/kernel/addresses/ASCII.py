class ASCII:
    
    def __init__(self): ...
    
    def maping(self):
        self.MAIN_ASCII_MAP = {
            'a': 97
        }