
#! MAIN BINARY SYSTEMS MODULE

#^ NOT WORKING | ONLY COPIED 

def hex_to_dec(n):
    res = 0
    for exp, digit in enumerate(str(n)[::-1]):
        res += int(digit) * (2 ** exp)
    return res
    
def dec_to_hex(n):
    res = []
    while n > 1:
        if int(n) / 2 % 1: res.append('1')
        else: res.append('0')
        n /= 2
    return ''.join(res[::-1])

def bin_to_hex(n):
    res = 0
    for exp, digit in enumerate(str(n)[::-1]):
        res += int(digit) * (2 ** exp)
    return res
    
def hex_to_bin(n):
    res = []
    while n > 1:
        if int(n) / 2 % 1: res.append('1')
        else: res.append('0')
        n /= 2
    return ''.join(res[::-1])