import os, time, subprocess

class DEV_MENUS_SCANNER: ...

class DEV_SCRIPT_RUNNER:
    def __init__(self,dev):
        self.cfg_path = r"/home/raw/Pulpit/PC/OS/syst/kernel/bootloader/boot.cfg"
        self.path = r"/home/raw/Pulpit/PC/OS/dev"
        self.scripts_path = os.path.join(self.path, dev, 'root/etc/scripts')
        
        os.makedirs(self.scripts_path, exist_ok=True)
        self.ext_type = 'NOT RECOGNIZED'
        self.start_up_info = False
        
        print('\t== BOOTLOADER ==\n\tver: 1.0.0.2.915\n\n')
    
    def config_(self, op):
        with open(self.cfg_path, 'r+') as f:
            for line in f:
                
                if op == 'asm':
                    if line.startswith('ENABLE_ASM_SCRIPTS='):
                        enable = line.strip().split('ENABLE_ASM_SCRIPTS=')[1]
                        try: enable = bool(enable)
                        except: return False
                        
                        if enable == True: return True
                        else: return False
        return False
                    
    def scanner(self):
        lines = []
        print('Loading, please wait!')
        for script in os.listdir(self.scripts_path):
            time.sleep(1.2)
            
            if script.endswith('.asm'):
                allowed = self.config_('asm')
                if allowed != True: exit()
                self.ext_type = 'x86_64 ASSEMBLY'
                
            self.script_path = os.path.join(self.scripts_path, script)
            with open(self.script_path, 'r+') as f:
                lines = f.readlines()
                
        self.parser(lines)
        os.system('clear')
        
    def parser(self,lines:list[str]):
        for line in lines:
            
            if line.startswith('PRINT'):
                time.sleep(0.7)
                data = line.split('(')[1].split(')')[0]
                self.console('print',data)
                
        self.console('$$S.T0P!','\nEnter to close ')
                
    def console(self,op, data):
        
        if self.start_up_info == False:
            print(f'LANGUAGE: {self.ext_type}')
            print(f'PARSER_VER: v1.0.5.14')
            print(f'OUTPUT for file "{self.script_path.split("/")[-1]}":\n')
            
            self.start_up_info = True
        if op == 'print':
            print(data)
            
        if op == '$$S.T0P!':
            input(data)
            time.sleep(2)
            exit()

class DEV_ISO_RUNNER:
    
    def run(path:str):
        script = os.path.join(path, "installator.py")
        subprocess.run(["python3", script, "run"])


class SYS_KERNEL: ...