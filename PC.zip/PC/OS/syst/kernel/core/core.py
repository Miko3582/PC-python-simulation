import random, time, os

#.TODO: rewrite all

class CORE:
    
    #!  MAIN ADDR MEMORY MODULE
    #!  SECOND MOST-IMPORTANT AFTER [kernel.py]
    
    def __init__(self):
        """**[ all op. will overwrite existing ]**"""
        self.SYSTEM_MEMORY = {}
    
    def generate_addr(self): ...
    
    def core_addr_add(self, addr, pointer):
        """- var: `addr` without prefixes -> [ 0x ]"""
        self.SYSTEM_MEMORY[f"0x{addr}"] = pointer
    
    def core_addr_del(self, addr, pointer):
        """IF `addr` not found try remove by `pointer`, BUT enter both**"""
        try: self.SYSTEM_MEMORY.pop(addr)
        except: self.SYSTEM_MEMORY.pop(pointer)
        
    def core_ret(self):
        """return whole `SYSTEM_MEMORY` in dict -> **[ADDR: POINTER]**"""
        return self.SYSTEM_MEMORY
    
    def core_addr_ret(self, addr):
        """return `pointer` by `addr`"""
        return self.SYSTEM_MEMORY[f"0x{addr}"]
    
    def core_pointer_ret(self, pointer):
        """return `addr` by `pointer`"""
        for _, v in self.SYSTEM_MEMORY.items():
            if pointer == v:
                return _
            

