"""
Dedicated for kernel file! Do not import!
"""

import sys, os
from typing import Any, Union, Literal
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '../../../../')))


import INTERFACES.SATA.SATA as sata_ifs_
from MOTHERBOARD.PROGRAMS.BIOS.bios import BIOS as bios_
from MOTHERBOARD.PROGRAMS.BIOS.bios import UEFI as uefi_
from RAM.core.engine import RAM as ram_
from RAM.core import cache as cache_
from RAM.core import stack as stack_
from RAM.core import user as user_
from RAM.ARCH.alloc import ALLOCATION as alloc_
from RAM.ARCH.BUS import BUS_R as bus_r_
from RAM.ARCH.BUS import BUS_W as bus_w_
from RAM.ARCH.decoder import DECODER as dec_
from RAM.ARCH.interrupts import INTERRUPTS as interr_
from RAM.ARCH import mem_map as mmp_
from RAM.diag.debug import OROW as orow_
from OS.interface.text_interface import desktop as deskt_
from OS.tools.animations import bars as bars_
from OS.syst.MODULES import SPA as spa_
from OS.syst.MODULES import SCM as scm_
from OS.syst.MODULES import ECM as ecm_
from OS.syst.MODULES import DA as da_
from OS.syst.MODULES import SSC as ecm_
from OS.syst.MODULES import SPB as spb_
from OS.syst.MODULES import SFC as sfc_
from OS.syst.MODULES import SERC as serc_
from OS.syst.MODULES import SEC as sec_
from OS.syst.MODULES import SDM as sdm_
from OS.syst.MODULES import SDD as sdd_
from OS.syst.MODULES import SBF as sbf_
from OS.syst.MODULES import RPT as rpt_
from OS.syst.MODULES import PMU as pmu_
from OS.syst.MODULES import PCM as pcm_
from OS.syst.MODULES import KCS as kcs_
from OS.syst.techs import CFE as cfe_
from OS.syst.techs import LFS as lfs_
from OS.syst.techs import UFE as ufe_
from OS.syst.kernel.addresses.ASCII import ASCII as ascii_
from OS.syst.kernel.addresses import bin as bin_
from OS.syst.kernel.addresses import hex as hex_
from OS.syst.kernel.bootloader import bootloader as bootloader_
from OS.syst.kernel.core.core import CORE as __CORE__
from OS.syst.kernel.core.regs import *
from OS.syst.kernel.drivers.sata import core as sata_dr_
from OS.syst.shell.CCU import USERS as users_
from OS.syst.shell.references.errors import SCM as scmr_
from OS.syst.sec import pers as pers_
