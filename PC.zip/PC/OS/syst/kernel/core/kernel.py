"""| H . A . L . |"""
#* ROOT KERNEL FILE
#* DO NOT EDIT ANYTHING!

#? MAIN PATH CONTROLLER
import sys, os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '../../../../')))
#! DO NOT MOVE ANY LINES !

#% MAIN IMPORTS
import time, random as r, shutil as s   # other-1
import threading as t                   # threading
import concurrent.futures as cf         # utils for threading
import pynput.keyboard as kb            # keyboard
import queue as qe                      # queue
import ctypes as ct                     # low-lv arch access

#% IMPORTS
from OS.syst.kernel.core.imports import *
from OS.syst.kernel.core.regs import *

# PATHS
devs = r"/home/raw/Pulpit/PC/OS/dev"
ports_software = r"/home/raw/Pulpit/PC/OS/pt"
ports_hardware = r"/home/raw/Pulpit/PC/MOTHERBOARD/PORTS"

# MAIN MODULES
class CPU: ...
class MEM: ...
class IO: ...
class FS: ...
class SECURITY: ...
class NETWORK: ...
class INTERRUPTS:
    
    
    class INPUT:
        "Self -> `@INPUT` | DO NOT USE !"
            
        # self
        def __init__(self): ...
        
        # ram
        def _rengda():
            """ram engine direct access"""
        
        # drivers
        def drv_init(self): ...
        def drv_unload(self): ...
        def drv_list(self): ...
        
        # devs
        def det_dev(self): ...
        def det_status(self): ...
        def det_event(self): ...
        def av_dev(self): ...
        def deav_dev(self): ...
        def set_dev_cfg(self): ...
        def get_dev_cfg(self): ...
        
        # listening
        def listen(self): ...
        def poll(self): ...
        def stop_listening(self): ...
        
        # exe & interr
        def exe_input(self): ...
        def trigger_interrupt(self): ... 
        
        # transfers
        def send_dtm(self):
            """data to module"""
            
        def rcv_dfm(self):
            """data from module"""
        
        # errors
        def h_error(self): ...
        def l_error(self): ...
        
        # vars
        def set_var(self): ...
        def get_var(self): ...
        def set_lvar(self): ...
        def get_lvar(self): ...
        
        # utils
        def vrf_data(self): ...
        def vld_dev(self): ...
        def lock_(self): ...
        def unlock_(self): ...
        def stress_test(self): ...
        def help(self): ...
                    
        #! SCANS
        def scan_port(self): ...
        def scan_elf(self): ...
        def scan_mem(self): ...
        def scan_disk(self): ...
        def scan_abuff(self): 
            """scan all *buffer"""
        
        #* SPECIAL FUNCT | SYS-X16-BASE
        
        def SYS_INPUT(self, prompt="", prefix="", suffix="", append_last_chain=False, 
                        append_last_char=False, max_lenght=-CONST_OFFSET_TRUE, allow_digits=True, only_digit=False,
                        use_join_method=False, join_method_str="", append_buffor=False, buff_indexes=CONST_OFFSET_FALSE, 
                        use_strip=False, skip_chars="", skip_chars_in_prefix_and_suffix=False, 
                        return_=False, use_split=False,  splitter="", *args, **kwargs):
            
            #?  about funct
            """This is main pointer for system-layer INPUTS.\n
            It work on interrupts level but can also work as a thread.\n
            Class `_SYS_INPUT_METHODS` have defined functions for manipulating strings.\n
            - - -
            `max_lenght` not checking whole input BUT only raw stream !
            """
            #!  INPUT BUILT-IN METHOD
            stream = input(prompt)
            stream = [x for x in stream]
            if max_lenght > 0:
                stream = stream[:max_lenght]
            output = join_method_str.join(stream)
            #return prefix + output + suffix
            return NotImplementedError
        
        #! METHODS
        class SYS_INPUT_METHODS:
            #.TODO: all the stuff
            def count_(self, sub="", stream="", INC=CONST_OFFSET_TRUE):
                return NotImplementedError
    
    #self class build object
    def __init__(self):
        """BUFF KERNEL CONTROL"""
        #& registers | pointers \ counters 
        #& special
        #& flags
        self.__buffsc = CONST_OFFSET_BFALSE
        """flag to pointing if buff size was ever changed"""
        
        #& rest | main | utils
        self.__BUFF = CONST_OFFSET_NULL
        "p-function for `INPUT` instance -> BUFFOR. Do not use!"
        self.__lockb = t.Lock()
        "Special `@threading` module p-variable instance, used while operating directly on `__BUFF`"
        self.__bsps = CONST_OFFSET_NULL
        "buffer size per sector | p-variable for `INPUT` instance. Do not use!"
        self.__bbt = CONST_OFFSET_NULL
        "buffer build type | "
        
    
    # utils
    def prt_base(self, x):
        """stdout for `x` as `str-chain` stream"""
        print(str(x))

    # buffer controll
    #.TODO -> need to rewrite all segment cos of change from `qe` type to `list[]` 
    #.TODO -> need to increse maxsizes of buff, cos of `buff` is global now
    #? its faster, simplier, kernel have less bugs and better control 
    
    def buff_size(self):
        """Return max size of buffer | not real buffer lenght !"""
        return self.__bsps

    def buff_rsize(self):
        """Return real size of buffer -> (allocated one & `!= None`)"""
        return len([x for x in self.__BUFF if x != None])
    
    def buff_bt(self):
        """Return buffer build type"""
        return self.__bbt
    
    def __buff_check(self, mode):
        """Do not use outside! This is local private function!\n
        This function is working only for kernel built-in as decorator!"""
        if not self.__BUFF:
            raise BufferError("Buffer hasn't been initialized yet!")
        
        if all(self.__BUFF) & (mode == 'ADD'):
            raise BufferError("Buffer is full!")

    def buff_init(self, maxsize=16, btype="FIFO"):
        """Create buffer with `max_size` and `btype` set.\n
        If `maxsize` is float, then convert it to int\n
        Build types:
        - `FIFO`
        - `LIFO`"""
        if maxsize < CONST_OFFSET_FALSE:
            raise BufferError("FATAL_ERROR: size <= 0")
        if isinstance(maxsize, float):
            maxsize = int(maxsize)
            
        # load
        self.__bsps = maxsize # for security reasons
        self.__bbt = btype
        
        # init buffer as -> [`None` * maxsize] structure
        self.__BUFF = [CONST_OFFSET_NULL] * maxsize
              
    def buff_add(self, item, index=-CONST_OFFSET_TRUE, db=False):
        """Add item to buff with optional index
        - - -
        `index` - write data in index and return True as confirm\n
        """
        self.__buff_check(mode='ADD')
        # set default
        X_BUFF_R0 = CONST_OFFSET_BFALSE #NOTE double use of `R0` register
        X_BUFF_R1 = CONST_OFFSET_NULL
        X16_LOCAL_BUFF = [] # init as empty #NOTE its double initialized as empty-list for security (*everywhere)
        X_BUFF_SIZE = self.__bsps
        X_BUFF_ISIZE = X_BUFF_SIZE - CONST_OFFSET_TRUE
        X_INPUT_P3 = -CONST_OFFSET_TRUE
        
        # copy BUFF to lbuff
        while self.__BUFF:
            with self.__lockb:
                X_BUFF_R1 = self.__BUFF[X_INPUT_P3]
                X16_LOCAL_BUFF.append(X_BUFF_R1)
                self.__BUFF.pop(X_INPUT_P3)
        
        # check if index in buff range
        if index > X_BUFF_ISIZE:
            raise BufferError(f"Index not in buff range! -> i:{index}/max:{X_BUFF_ISIZE}")
        
        # set `R0` flag to True & write item to lbuff index
        if -CONST_OFFSET_TRUE < index < X_BUFF_SIZE:
            with self.__lockb:
                # write item directly to the list index
                X16_LOCAL_BUFF[index] = item
                X_BUFF_R0 = CONST_OFFSET_BTRUE
        
        # return all to BUFF
        with self.__lockb:
            for i in X16_LOCAL_BUFF:
                self.__BUFF.append(i)
                
        # return `R0` flag is True -> if item
        if X_BUFF_R0: return (X_BUFF_R0 == CONST_OFFSET_BTRUE)

        # check if there is enough free space to add items from `item`
        if isinstance(item, list):
            #.NOTE #? it didnt work itself (without `self.__bsps`), its look like python is not saving global imported value
            X_BUFF_R0 = len([x for x in X_BUFF_R0 if x != None]) # size to add + ignore `None` value
            X_BUFF_R1 = len(self.buff_rsize()) # used size of buffer
            if (X_BUFF_R0 + X_BUFF_R1) > X_BUFF_SIZE:
                raise BufferError("Not enaugh space in buffer!")
        
        #> handle `item` types:
        
        # - add to BUFF if item is -> [int, float, str]
        if isinstance(item, Union[int, float, str]):
            with self.__lockb:
                for i in range(X_BUFF_SIZE):
                    if self.__BUFF[i] == None:
                        X_BUFF_R1 = i
                        break
                self.__BUFF[X_BUFF_R1] = item
                if db: int('a')
                return CONST_OFFSET_NULL
        
        # - iterate on item (list) item's and add to BUFF
        if isinstance(item, list):
            with self.__lockb: #* -> not good for bigger buffs
                for i in item:
                    self.__BUFF.append(i)
            return CONST_OFFSET_NULL
        else:
            raise TypeError("Wrong type for `item` variable!\nAcceptable: [int/float/str/list]")
    
    def buff_flush(self, start=-CONST_OFFSET_TRUE, stop=-CONST_OFFSET_TRUE):
        """Clear buff using optional indexes as start & stop for clearing and return bool as confirm\n
        To clear whole buff stay with `-1` default values"""
        
        # set to default
        X_INPUT_C0 = CONST_OFFSET_FALSE
        X_INPUT_P3 = -CONST_OFFSET_TRUE
        X32_LOCAL_BUFF = []
        
        # load
        X_BUFF_R0 = start
        X_BUFF_R1 = stop
        X_BUFF_SIZE = self.__bsps
        
        # set all to default -> None | #? slower and harder method changed to simplier and faster (1 way is more advanced and more flexible)
        #.OLD: #//if all(x == -CONST_OFFSET_TRUE for x in (X_BUFF_R0, X_BUFF_R1)):...
        if X_BUFF_R0 == -CONST_OFFSET_TRUE and X_BUFF_R1 == -CONST_OFFSET_TRUE:
            for i in range(X_BUFF_SIZE):
                self.__BUFF[i] == None
        
        # if indexes are bigger than -1
        else:
            while self.__BUFF:
                with self.__lockb:
                    # update regs
                    X_INPUT_C0 += CONST_OFFSET_TRUE
                    X_BUFF_R0 = self.__BUFF[X_INPUT_P3]
                    self.__BUFF.pop(X_INPUT_P3)
                    
                    # check if in range
                    if not (X_BUFF_R0 <= X_INPUT_C0 <= X_BUFF_R1): 
                        X32_LOCAL_BUFF.append(X_BUFF_R0)
                    else: 
                        X32_LOCAL_BUFF.append(CONST_OFFSET_NULL)
        
        # return True if all item in BUFF except range is None (reseted) 
        return all(x is None for x in self.__BUFF[:X_BUFF_R0-CONST_OFFSET_TRUE] + self.__BUFF[X_BUFF_R1:])
        
    def buff_get(self, item:Any=CONST_OFFSET_NULL, index=-CONST_OFFSET_TRUE, counter=-CONST_OFFSET_TRUE, 
                 as_str=False, joiner='', prtc=False, op="FIFO", clb=True, ret_index=False, ret_size=False):
        #? INFO
        """Return buff in multiply ways & types.\n
        - - -
        If `item` != `None`: 
        - return True if `item` in `BUFF`, otherwise return False\n
        - that's not support converting values:
            - WARNING: Return False even if -> `item` = '1' & `BUFF` = [1]\n
        - - -
        `index` - return buffer[index] -> data; if in range & index > -1\n
        `counter` - load n items to 32-lbuff from buff
        `as_str` - return as str:
        - (join with `joiner` value)\n
        NOT WORKING -> `prtc` - print content as str\n
        `op` - choose default return operation type [*FIFO / LIFO / RANDOM]\n
        `clb` - remove buff content like `get()` method
        `ret_index` - return first index of item if exists, otherwise None\n
        `ret_size` - return size of buff
        - - -
        `32-lbuff` - storing all buff content regardless of the `counter` value
        `64-lbuff`
        """
            
        # set defaults
        # using 2 lbuff -> x32 & x64
        self.__buff_check(mode='GET')
        X32_LOCAL_BUFF = [] # used only to return full BUFF regardless of the `counter` value
        X64_LOCAL_BUFF = [] 
        X_INPUT_C0 = CONST_OFFSET_FALSE
        X_BUFF_R0 = counter
        X_BUFF_R1 = CONST_OFFSET_NULL
        X_BUFF_SIZE = self.__bsps
        X_INPUT_P0 = index
        X_INPUT_P3 = -CONST_OFFSET_TRUE
        
        # copy BUFF to lbuff-64
        # if `C0` < `R0` add to lbuff-32 & inc `C0`
        while self.__BUFF:
            with self.__lockb:
                X_BUFF_R1 = self.__BUFF[X_INPUT_P3]
                self.__BUFF.pop(X_INPUT_P3)
                X64_LOCAL_BUFF.append(X_BUFF_R1)
                if X_INPUT_C0 < X_BUFF_R0:
                    X32_LOCAL_BUFF.append(X_BUFF_R1)
                    X_INPUT_C0+=1   
        
        # check `clb` flag, if True -> do not return items from lbuff-64 to BUFF
        if clb:
            self.buff_flush()
        else:
            for i in X64_LOCAL_BUFF:
                with self.__lockb:
                    self.__BUFF.append(i)
        
        # from now lbuff-32 is not used so we freeing space
        X32_LOCAL_BUFF = X_BUFF_FREE
        
        # return only len | IMPORTANT -> always after checking `clb` flag, to not return empty BUFF
        if ret_size:
            return len(X64_LOCAL_BUFF)
    
        # check if index in range & then return it value
        if (X_INPUT_P0 >= CONST_OFFSET_FALSE) & (X_INPUT_P0 < X_BUFF_SIZE):
            return X64_LOCAL_BUFF[X_INPUT_P0]
        
        # return bool for `item` in lbuff | return first item index or None if not found
        if item is not CONST_OFFSET_NULL: 
            if ret_index is CONST_OFFSET_BTRUE:
                for i in range(len(X64_LOCAL_BUFF)):
                    if X64_LOCAL_BUFF[i] == item:
                        return i
                return CONST_OFFSET_NULL
            return item in X64_LOCAL_BUFF
        
        #> outputs:
        
        # - return whole lbuff-64 if `prnt` flag is True & lbuff-64 is not empty else return 0
        #.TODO: connect this to print() function to display content
        if (prtc is True) & X64_LOCAL_BUFF:
            ... #$ return X64_LOCAL_BUFF
        elif (prtc is True) & (X64_LOCAL_BUFF):
            ... #$ return CONST_OFFSET_FALSE
                
        # - return str lbuff-64 content if `as_str` flag is True & -||-
        # - then convert all items to str, join with `joiner` value & return
        if (as_str is True) & (len(X64_LOCAL_BUFF) > CONST_OFFSET_FALSE):
            #?  converting buff items to str to be able to use `join` method -> (works with str type only)
            X64_LOCAL_BUFF = [str(i) for i in X64_LOCAL_BUFF]
            return f'{joiner}'.join(X64_LOCAL_BUFF)
        
        # - return lbuff-64 in multiply formats: LIFO / FIFO / RANDOM
        #.TODO: write own `shuffle` algoritm -> for optimalization
        if op.lower() == "fifo":
            return X64_LOCAL_BUFF
        elif op.lower() == "lifo":
            return X64_LOCAL_BUFF[::-1]
        elif op.lower() == "random":
            r.shuffle(X64_LOCAL_BUFF)
            return X64_LOCAL_BUFF
        else:
            raise BufferError("`op` type is not acceptable!")

    def buff_list(self, as_list=False, as_str=False, joiner=''):
        """List all items in BUFF\n
        If not any is True return True if BUFF is not empty\n
        - - -
        `as_list` - return as list\n
        `as_str` - return as str
        - (join with `joiner` value)
        """
        #? call check funct -> ... ; for now its stay commented
        #$ self.__buff_check(mode='LS')
        
        # set default
        X32_LOCAL_BUFF = []
        X_INPUT_P3 = -CONST_OFFSET_TRUE
        X_BUFF_R0 = CONST_OFFSET_NULL
        X_INPUT_P0 = CONST_OFFSET_FALSE
        #int('a')
        # copy BUFF to lbuff-32
        while self.__BUFF:
            with self.__lockb:
                X_BUFF_R0 = self.__BUFF[X_INPUT_P0]
                X32_LOCAL_BUFF.append(X_BUFF_R0)
                self.__BUFF.remove(X_BUFF_R0)
            #X_INPUT_P0+=1
            
        # return items from lbuff-32 to BUFF
        for i in X32_LOCAL_BUFF:
            self.__BUFF.append(i)
        
        # check `as_list` & return as list
        if as_list: 
            return X32_LOCAL_BUFF
        
        # check `as_str` -> convert to str, join with `join`
        if as_str:
            X32_LOCAL_BUFF = [str(i) for i in X32_LOCAL_BUFF]
            return f'{joiner}'.join(X32_LOCAL_BUFF)
        
        return all(x for x in X32_LOCAL_BUFF if x != None)
    
    #.TODO: remove or check if its needed
    #.TODO: we should write sth more advanced for this whole part
    def buffS(self, newsize=16):
        """Set buff size for each sector with this function\n
        Working as long as `__buffsc` is False\n
        Available values -> [8, 16, 32, 64]\n
        Return bool as confirm\n
        - - -
        WARNING: Will overwrite whole buffer"""
        X_BUFF_R0 = newsize
        if self.__buffsc: return False
        if X_BUFF_R0 not in [8, 16, 32, 64]:
            raise BufferError(f"`{X_BUFF_R0=}` is not allowed as a buff size | -> [8, 16, 32, 64]")
        self.__bsps = X_BUFF_R0
        for _ in range(X_BUFF_R0 - CONST_OFFSET_TRUE):
            self.__BUFF.put(CONST_OFFSET_FALSE)
        return True
    
class PROCESS: ...#
class MODULES: ...
class _SYS: ...
class IPC: ...
class PERMISSIONS: ...
class DRIVERS: ...
class INTERFACES: ...
class IMAGES: ...
class OTHER: ...
class CONTROLLERS: ...
class USBHub:
    def __init__(self):
        pass
    
    

#&  ===================================================================  &#


#* INPUT INSTANCE
BUFF = INTERRUPTS()
"""
IF `__BUFF` is `CONST_OFFSET_NULL ` - (None Register), you must initialize it first.\n
Attempting to directly operate on classes and their objects is disabled.\n
Only available using kernel built-in functions.\n
- - -
If something start with prefix `__` do not use that!\n
This is private-local-object & can not be used outside.\n
Instead use built-in function & or buff-drivers to manipulate them.\n
"""
