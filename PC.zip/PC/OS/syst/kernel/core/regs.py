"""This is VBR (Virtual Base Register) registers\n
If PBR (Physical Base Register) needed use `drivers.BASE.pbr` module\n
If DBR (Digits Base Register) needed use `drivers.BASE.dbr` module\n
- - -
For now:\n
WARNING -> `pbr` is importet and working\n
WARNING -> `dbr` is importet and working\n
- - -
- prefix for `VBR`      -> "X_"
- prefix for `PBR`      -> "H_"
- prefix for `DBR`      -> "D_"
- prefix for `BBR`      -> "B_"
"""

from ..core.vbr import * # WARNING: HUGE LIB
from ..drivers.BASE.pbr import *
from ..drivers.BASE.dbr import *
from typing import Any

X4_KB_BASE = 0x04
"x4 base register for keyboard modules & drivers"

X8_KB_BASE = 0x08
"x8 base register for keyboard modules & drivers"

X16_KB_BASE = 0x10
"x16 base register for keyboard modules & drivers"

X32_KB_BASE = 0x20
"x32 base register for keyboard modules & drivers"

X64_KB_BASE = 0x40
"x64 base register for keyboard modules & drivers"

CONST_OFFSET_BTRUE = True
"BASE abstraction register | -> True"
CONST_OFFSET_BFALSE = False
"BASE abstraction register | -> False"
CONST_OFFSET_TRUE = 0x1
"BASE abstraction register | -> 1"
CONST_OFFSET_FALSE = 0x0
"BASE abstraction register | -> 0"
CONST_OFFSET_NULL = None
"BASE abstraction register | -> None"

X_BUFF_SIZE = 0x0
"Size of buffer | Do not edit !"
X_BUFF_ISIZE = 0x0
"""Size of indexes buffer | Do not edit !\n
That simplier: `X_BUFF_SIZE` - 1\n
Caused of numerating from 0."""

#!  GPR BUFF Ri
X_BUFF_R = Any
"""| ONLY INFO | Do not use this one !\n
`X_BUFF_R[0-7]` -> GPR's for `@INPUT` sections"""
X_BUFF_R0 = 0x0
X_BUFF_R1 = 0x0
X_BUFF_R2 = 0x0
X_BUFF_R3 = 0x0
X_BUFF_R4 = 0x0
X_BUFF_R5 = 0x0
X_BUFF_R6 = 0x0
X_BUFF_R7 = 0x0

#!  INPUT COUNTERs
X_BUFF_C = Any
"""| ONLY INFO | Do not use this one !\n
`X_BUFF_C[0-3]` -> Counter for `@INPUT` sections"""
X_INPUT_C0 = 0x0
X_INPUT_C1 = 0x0
X_INPUT_C2 = 0x0
X_INPUT_C3 = 0x0

#!  INPUT POINTERs
X_BUFF_P = Any
"""| ONLY INFO | Do not use this one !\n
`X_BUFF_C[0-3]` -> Pointer for `@INPUT` sections"""
X_INPUT_P0 = 0x0
X_INPUT_P1 = 0x0
X_INPUT_P2 = 0x0
X_INPUT_P3 = 0x0

X4_LOCAL_BUFF = []
"local x4 buffer for each function"

X8_LOCAL_BUFF = []
"local x8 buffer for each function"

X16_LOCAL_BUFF = []
"local x16 buffer for each function"

X32_LOCAL_BUFF = []
"local x32 buffer for each function"

X64_LOCAL_BUFF = []
"local x64 buffer for each function"

X128_LOCAL_BUFF = []
"local x128 buffer for each function"

X256_LOCAL_BUFF = []
"local x256 buffer for each function"

X_BUFF_FREE = []
"Reset buff to default `[]` & free space"