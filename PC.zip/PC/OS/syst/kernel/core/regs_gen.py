import random

# Konfiguracja rejestrów
regs = [
    "USB", "DRIVER", "IO", "FS", "DEV", "DISK", "SATA"
]

# Ilość elementów w poszczególnych sekcjach
section_config = {
    "R": 16,  # Ilość rejestrów
    "C": 8,   # Ilość licznikow
    "P": 8,   # Ilość wksaznikow
    "S": 12,   # Ilość r-specjalnych
    "F": 32   # Ilość flag
}

# Pola dodatkowe
extra_fields = [
    "SIZE", "RSIZE", "USIZE", "FSIZE", "CFG", "CONN", "TR", "TR_SPEED", "MODE", "STATUS", "ADDR_START", "ADDR_END"
]

# Lokalne bufory
local_buffers = [16, 32, 64, 128, 256, 512]

# Ścieżka pliku
path = r'/home/raw/Pulpit/PC/OS/syst/kernel/core/vbr.py'

# Generowanie kodu
with open(path, 'w+') as f:
    for reg in regs:
        f.write(f"#\t== {reg} ==\n")
        f.write('\n'*1)
        # Rejestry "R"
        for i in range(section_config["R"]):
            f.write(f"X_{reg}_R{i} = 0x0\n")
        f.write('\n'*2)
        # Konfiguracje "C"
        for i in range(section_config["C"]):
            f.write(f"X_{reg}_C{i} = 0x0\n")
        f.write('\n'*2)
        # Porty "P"
        for i in range(section_config["P"]):
            f.write(f"X_{reg}_P{i} = 0x0\n")
        f.write('\n'*2)
        # Specjalne "S"
        for i in range(section_config["S"]):
            f.write(f"X_{reg}_S{i} = 0x0\n")
        f.write('\n'*2)
        # Flagi "F"
        for i in range(section_config["F"]):
            f.write(f"X_{reg}_F{i} = 0x0\n")
        f.write('\n'*2)
        # Dodatkowe pola
        for field in extra_fields:
            f.write(f"X_{reg}_{field} = 0x0\n")
        f.write('\n'*2)
        # Lokalne bufory
        for buf_size in local_buffers:
            f.write(f"X_{buf_size}_{reg}_LOCAL_BUFF = []\n")
        f.write('\n'*3)
