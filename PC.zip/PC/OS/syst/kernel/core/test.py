
# TEST 1

from kernel import *
x = BUFF
x.buff_init(maxsize=5, btype="FIFO")
x.buff_add(item=1)
x.buff_add(item=2, db=True)
x.buff_add(item=3)
x.prt_base(x.buff_list(as_list=True))



# works good :/     did in 20h ...
# edit1: not yet mf ... almost 30h
# edit2: still dont work as i wanted ... bruh -> kernel is different
