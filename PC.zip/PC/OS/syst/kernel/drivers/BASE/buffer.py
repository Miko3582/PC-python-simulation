"""
BASE System Driver | as bridge -> `__BUFF` ~ root\n
- - -
To create buffer use -> `BufferDriver_`\n

"""
import sys, os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '../../../../')))

# import kernel stuf ...
from OS.syst.kernel.core.ALL import *

class BufferDriver_:
    
    def __init__(self, maxsize=64, btype="FIFO"):
        """`maxsize` set to 64, but default its 16, this configuration is only for drivers"""
        b.buff_init(maxsize=maxsize) # "turn on" the buffer
        b.buffS(maxsize)

    def write(self, data=CONST_OFFSET_NULL, clear=False):
        
        b.buff_add(item=data)
        X_BUFF_R1=b.buff_get(item=data, clb=clear)
        return X_BUFF_R1
        
    #.TODO -> REMOVE or REBUILD
    def writet(self, data=CONST_OFFSET_NULL, index=-CONST_OFFSET_TRUE, clear=False):
        """Not working! Use `write` function instead."""
        # double control -> (second in funct `buff_add`)
        X_BUFF_R1 = b.buff_size() # get real size of usage buff
        #// no access to p-variable -> `__bsps`
        X_INPUT_P0 = index

        if (X_BUFF_R0 == X_BUFF_R1):
            raise BufferError("Buffer size is not synchronized!")
        if (X_INPUT_P0 < X_BUFF_R0):
            raise BufferError("List index not in buffer range")
        return b.buff_add(item=data, index=X_INPUT_P0)
    
    def read(self, data=CONST_OFFSET_NULL, index=-CONST_OFFSET_TRUE, check=CONST_OFFSET_BFALSE, clear=False):
        
        X_INPUT_P0 = index
        X_BUFF_R0 = CONST_OFFSET_NULL
        
        if X_INPUT_P0 >= b.buff_rsize():
            raise BufferError("List index not in buffer range")
        if data is CONST_OFFSET_NULL:
            if check == CONST_OFFSET_BTRUE:
                X_BUFF_R0 = b.buff_get(index=X_INPUT_P0, clb=clear)
                return X_BUFF_R0 is not CONST_OFFSET_NULL
            return b.buff_get(index=X_INPUT_P0, clb=clear)
        return b.buff_get(item=data, ret_index=True, clb=clear) # return first index of value if exists otherwise return None
        
    def fsize(self):
        """Return free buffer size"""
         # return free size (full size - `@usize` funct)
        return b.__bsps - self.usize()
        
    def usize(self, clear=False):
        """Return used buffer size"""
        return int(b.buff_get(ret_size=True, clb=clear))

    def full(self):
        """Return True if buffer is full"""
        return b.__bsps == len(b.buff_list(as_list=True))

    def btype():
        """Return str repr of buffer build type.\n
        Do not use this info -> `NotImplemented`"""
        return b.buff_bt()
        
        
    def utils(self, mode=CONST_OFFSET_FALSE):
        """Modes:
        - 1 -> RESET
        - 2 -> RESTART
        - 3 -> RELOAD
        - 4 -> REMOVE
        - 5 -> [*hide*] | do not use ! ! !        
        """
        
        if mode == 1: ...
        if mode == 2: ...
        if mode == 3: ...
        if mode == 4: ...
        if mode == 5:
            raise PermissionError("Option is not availble")
            #'TODO -> root permission handler

    def test(self):
        print(self.write(data=1))
        print(self.write(data=2))
        print(self.write(data=3))
        print(self.read(data=2))
        print(self.utils(mode=1))
        
b = BUFF # arch obj -> instance of `INTERR`; can be used if instance exists (there must be `buff_init` called)
"local object -> DO NOT USE !"
"""
Instance of buffer driver is global for all operations.\n
Create multiply instances if you going to run them as threads.\n
Best way is to create one global instance and import whenever is needed\n
"""
