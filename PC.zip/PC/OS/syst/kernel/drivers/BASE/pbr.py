"""root class driver giving access to physical base registers"""


