"""
BASE Keyboard Driver | as bridge -> `I/O` ~ dev
- - -
To create buffer use -> `KbDriver_`
"""



from base import *

class KbDriver_:
    
    def __init__(self):
        pass
    