import sys, os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '../../../../')))

"""Main SATA interface handler\n
Main SATA driver file\n

Module is connected with:
- SATAFileSystem
- SATAInterface
- SATACore
- SATAConfig
- SATA_HAL_REPR
- RAM_ (driver)

"""

from OS.fss.ext4.core import * # from both files (fs & interface); all imports is in interface file (so as not repeat it twice)

