LXSP01=True
LXSP02=False
RSPx0=False
RSPx1=False
LX92=False
LX36=False
LXSP82=False