# Creator Controller Menu

import time,os,random

class USERS:
    
    def __init__(self) -> None:
        self.path = r'/home/raw/Pulpit/PC/OS/dev/C/root/home'
        self.upath = r''
        self.data = {}
            
    def check1(self,name,nick,pwd,cpwd,db_conn,gr_conn):
        e = 0
        if len(name) < 4 or len(name) > 20:
            print("Name lenght in range 4-20 sings || 4 <= 'name' <= 20")
            e += 1  
        
        if len(nick) > 10:
            print("Nick lenght in range 0-10 sings || 0 <= pwd <= 10")
            e += 1
        
        if len(pwd) < 4 or len(pwd) > 20:
            print("Password lenght in range 4-16 sings || 4 <= 'pwd' <= 16")
            e += 1
        
        if cpwd != pwd:
            print("Passowrd are not the same!")
            e += 1
        
        if not isinstance(db_conn,bool):
            print("Work with 'True/False' only")
            e += 1

        if not isinstance(gr_conn,bool):
            print("Work with 'True/False' only")
            e += 1
            
        if e == 0: return True
        else: return False
        
    def CREATE(self): 
        
        # COLLECTING DATA
        
        os.system('clear')
        time.sleep(2)
        name = input("Name: ")
        nick = input("Nick (optional): ")
        time.sleep(0.7)
        pwd = input("Password: ")
        cpwd = input("Confirm password: ")
        time.sleep(0.7)
        db_conn = input("Connect to database (Y/n): ")
        gr_conn = input("Connect to group (Y/n): ")
        time.sleep(1.7)
        
        if db_conn == 'Y': db_conn = True
        else: db_conn = False
        if gr_conn == 'Y': gr_conn = True
        else: gr_conn = False
        
        check = self.check1(name,nick,pwd,cpwd,db_conn,gr_conn)
        if check == False: return
        
        print('Please wait ...')
        time.sleep(7.1)
        key = [str(random.randint(0,9)) for _ in range(16)]
        key = ''.join(key)
        
        time.sleep(3)
        print('\nUSER:')
        print(f' -name: {name}')
        if nick == '':
            print(f' -nick: -')
        else:
            print(f' -nick: {nick}')
        
        print("\nSECURITY:")
        print(f' -password: {pwd}')
        print(f' -security_key: {key}')
        
        print('\nCONNECTIONS:')
        print(f' -db_conn: {db_conn}')
        print(f' -gr_conn: {gr_conn}')
        
        ver = input('\nSave settings and create user (Y/n): ')
        if ver == 'n':
            print('...')
            time.sleep(0.7)
            self.CREATE()
        
        # CREATING STRUCTURE
        
        self.upath = os.path.join(self.path,name)
        os.mkdir(self.upath)
        
        mtdata = ['files','folders','obj','sys']
        userfolders = ['Downloads','Documents','Other','Desktop']
        sysfolders = {
            'config': ['bashrc.ini','sys_config.ini','user_prefs.ini','conn_settings.ini'],
            'tmp': ['session.tmp','conn_data.tmp','trash.tmp'],
            'bin': ['auto_save.xowl','auto_config.xowl','auto_backup.xowl'],
            'logs': ['system.log','error.log','operations.log','fs.log'],
            'mem': ['swapfile.cfg','paging.cfg','allocation_tab.ini'],
            'mt': ['net.xowl'],
            }        

        e = 0
        time.sleep(0.2)
        
        for folder in userfolders:
            try:
                folder_path = os.path.join(self.upath, folder)
                os.mkdir(folder_path)
                print(f"Created user dir: {folder}")
                time.sleep(0.3)
                os.system('clear') 
            except: e+=1
            
        for sysfolder, files in sysfolders.items():
            sysfolder_path = os.path.join(self.upath, sysfolder)
            try:
                os.mkdir(sysfolder_path)
                print(f"Created system dir: {sysfolder_path}")
                time.sleep(0.1)
                os.system('clear')
                for obj in files:
                    file_path = os.path.join(sysfolder_path, obj)
                    with open(file_path, 'w') as f: ...
                    print(f"Created file: {obj}")
                    time.sleep(0.1)
                    os.system('clear') 
            except:e+=1
        
        mtdata_path = os.path.join(self.upath, 'mt')
        for folder in mtdata:
            try:
                dir_path = os.path.join(mtdata_path, folder)
                os.mkdir(dir_path)
                print(f"Created meta_data dir: {sysfolder_path}")
                time.sleep(0.1)
                os.system('clear')
            except:
                e+=1
            
        if e != 0:
            print("Sorry, creating user data structures goes wrong! Please, try again.")

        # SAVING CREATOR_DATA