class SCM:
    def bf_ERROR():
        print("SCM MODULE ERROR || File is not configured correctly.")