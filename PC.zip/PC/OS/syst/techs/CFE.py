#Config Files Encrypting

import time,os,random

#DATA
ext = [".ini", ".tmp", ".xowl", ".log",".cfg"]
val = [75,9,41]

class ASNA_75:
    """
    Encrypting alghoritm:
    ASCII + 75
    """
    def DECRYPTER(fpath:str):
        if not fpath.endswith(ext[0] or ext[1]):
            print("WRONG FILE FORMAT")
            exit()
        with open(fpath, 'r+') as f:
            coded_data = f.read().split()
        decode_data = []
        for char in coded_data:
            decode_data.append(int(char))
        decoded_data = [chr(data-val[0]) for data in decode_data]
        decoded_data = ''.join(decoded_data)
        return decoded_data

    def ENCRYPTER(data,fpath:str):
        if not fpath.endswith(ext[0] or ext[1]):
            print("WRONG FILE FORMAT")
            exit()
        os.system('clear')
        coded_data = [str(ord(char)+val[0]) for char in data]
        coded_data = ' '.join(coded_data)
        with open(fpath, 'w') as f:
            f.write(coded_data + "\n")
        return coded_data

class ASOC_9SC:
    """
    Encrypting alghoritm:
    ASCII + 9 -> oct + method: _swapcase_
    """
    def DECRYPTER(fpath:str):
        if not fpath.endswith(ext[0] or ext[1]):
            print("WRONG FILE FORMAT")
            exit()
        with open(fpath, 'r+') as f:
            coded_data = f.read().split()
        coded_data = [char.swapcase() for char in coded_data]
        decoded_data = [int(char,8) for char in coded_data]
        decoded_data = [chr(char-val[1]) for char in decoded_data]
        decoded_data = ''.join(decoded_data)
        return decoded_data
        
    def ENCRYPTER(data,fpath:str):
        if not fpath.endswith(ext[0] or ext[1]):
            print("WRONG FILE FORMAT")
            exit()
        os.system('clear')
        coded_data = [ord(char)+val[1] for char in data]
        coded_data = [oct(char) for char in coded_data]
        coded_data = ' '.join(coded_data)
        coded_data = coded_data.swapcase()
        with open(fpath, 'w') as f:
            f.write(coded_data + "\n")
        return coded_data

class ASHX_41r:
    """
    Encrypting alghoritm:
    ASCII + 41 -> hex + reverse - prefix
    """
    def DECRYPTER(fpath:str):
        if not fpath.endswith(ext[0] or ext[1]):
            print("WRONG FILE FORMAT")
            exit()
        with open(fpath, 'r+') as f:
            coded_data = f.read().split()
        decoded_data = [f"{char}x0" for char in coded_data]
        decode_data = []
        for item in decoded_data:
            c = len(item)-1
            rev_item = []
            for _ in item:
                rev_item.append(item[c])
                c-=1
            rev_item = ''.join(rev_item)
            decode_data.append(rev_item)
            decode_data = [int(char,16) for char in decode_data]
        decode_data = [chr(char-val[2]) for char in decode_data]
        decode_data = ''.join(decode_data)
        return decode_data
        
    def ENCRYPTER(data,fpath:str):
        if not fpath.endswith(ext[0] or ext[1]):
            print("WRONG FILE FORMAT")
            exit()
        os.system('clear')
        coded_data = [ord(char)+val[2] for char in data]
        coded_data = [hex(char) for char in coded_data]
        code_data = []
        for item in coded_data:
            c = len(item)-1
            rev_item = []
            for _ in item:
                rev_item.append(item[c])
                c-=1
            rev_item = ''.join(rev_item)
            code_data.append(rev_item)
        code_data = [str(item).split('x0')[0] for item in code_data]
        code_data = ' '.join(code_data)
        with open(fpath, 'w') as f:
            f.write(code_data + "\n")
        return code_data
        
#EXAMPLE IN FILES: "key=1\ndefault=0"