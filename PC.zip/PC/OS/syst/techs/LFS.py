# Log Files System
import time, uuid, os

# TEST
class LOGS:
    def __init__(self):
        self.time = time.strftime('%H:%M:%S')
        self.no = 215
        self.lv = 'INFO'
        self.uuid = uuid.uuid4()
        self.op = 'rm fb_icon.png -s'
        self.dir = '/home/raw/Desktop/data/icons'
        self.status = 'FAILED'
        self.type = 'ID'
        
        path = r'/home/raw/Pulpit/PC/OS/var/log'
        LOG = f'#{self.time},{self.no} {self.lv} - {self.type}: {self.uuid}\nSTATUS: {self.status} | DIR: {self.dir} | OPERATION: {self.op}'
        
        with open(os.path.join(path, f"console_log-{self.no}.log"), 'a+') as f:
            f.write(LOG+2*'\n')