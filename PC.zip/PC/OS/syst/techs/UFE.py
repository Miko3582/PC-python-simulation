#User Files Encrypting

import time,os,random
exts = [".ini", ".tmp", ".xowl", ".log",".cfg"]

class _KEY_:
    """
    Encrypting adapter for @AAOCHX_srp()
    """
    def getkey():
        return [str(random.randint(1,9)) for _ in range(8)]
    def setkey():
        KEY = _KEY_
        key = KEY.getkey()
        result = []
        for digit in key:
            ex = int(digit)*6+6
            result.append(str(ex))
        return result
    def decryptkey(code,key:str):
        keys = [int(digit) for digit in key.split()]
        return keys[code+1]
        
class AAOCHX_srp:
    """
    Encrypting alghoritm:
    ASCII - _KEY_.getkey() -> ASCII + _KEY_.getkey() -> OCT + rev -> HEX - prefix
    """
    def DECRYPTER(fpath:str):
        path = r'/home/raw/Pulpit/PC/OS/syst/techs/UFE_data.key'
        ext=fpath.split('.')[1]
        ext = f'.{ext}'
        if not ext in exts:
            print("WRONG FILE FORMAT")
            exit()
        os.system('clear')
        with open(fpath, 'r+') as f:
            coded_data = f.read().split()
        file = fpath.split('/')[-1]
        with open(path, 'r+') as f:
            for line in f:
                if line.startswith(f'{file}|'):
                    vkey = int(line.split('|')[1].split('::')[0])
                    key = line.split('::')[1]
                    break
        try:
            KEY = _KEY_.decryptkey(vkey,key)
        except:
            print("WRONG DATA INPUT")
            exit()
        decoded_data = [f"0x{char}" for char in coded_data]
        decoded_data = [int(char,16) for char in decoded_data]
        decoded_data = decoded_data[::-1]
        decoded_data = [int(oct(char),8) for char in decoded_data]
        decoded_data = [chr(char) for char in decoded_data]
        decoded_data = [ord(char)-KEY for char in decoded_data]
        decoded_data = [chr(char+KEY) for char in decoded_data]
        return ''.join(decoded_data)
        
    def ENCRYPTER(data,fpath:str):
        ext=fpath.split('.')[1]
        ext = f'.{ext}'
        if not ext in exts:
            print("WRONG FILE FORMAT")
            exit()
        os.system('clear')
        key = _KEY_.setkey()
        x = random.randint(0,len(key)-1)
        vkey = int(key[x])
        path = r'/home/raw/Pulpit/PC/OS/syst/techs'
        file = fpath.split('/')[-1]
        key_file = ' '.join(key)
        with open(os.path.join(path, 'UFE_data.key'), 'w+') as f:
            f.write(f'{file}|{x}::{key_file}')
        coded_data = [ord(char)-vkey for char in data]
        coded_data = [chr(char+vkey) for char in coded_data]
        coded_data = [ord(char) for char in coded_data]
        coded_data = [oct(char) for char in coded_data]
        coded_data = coded_data[::-1]
        coded_data = [int(char,8) for char in coded_data]
        coded_data = [hex(char) for char in coded_data]
        coded_data = [char.removeprefix('0x') for char in coded_data]
        coded_data = ' '.join(coded_data)
        with open(fpath, 'w') as f:
            f.write(f"{coded_data}\n")
        return coded_data

#EXAMPLE IN FILES: "key=1\ndefault=0"