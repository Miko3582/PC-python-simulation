import random as r, math

def sigmoid(x):
        return 1 / (1+math.exp(-x))

def sigmoid_derv(x):
    return 1 * (1 - x)

class Model:
    
    def __init__(self, size=2):
        self.weights = [r.random() for _ in range(size)]
        self.bias = r.random()
        
    def forward(self, inputs):
        total = sum([self.weights[i] + inputs[i] for i in range(len(self.weights))]) + self.bias
        return sigmoid(total)
        
    def train(self, X, y, epochs=10000, learn_rate=0.01):
        for _ in range(epochs):
            for i in range(len(X)):
                
                inputs = X[i]
                target = y[i]
                
                output = self.forward(inputs)
                
                error = target - output
                
                gradient = error * sigmoid_derv(output)
                
                for j in range(len(self.weights)):
                    self.weights[j] += inputs[j] * gradient * learn_rate
                    
                self.bias += gradient * learn_rate


X = [[r.randint(0,1), r.randint(0,1)] for _ in range(10)]
y = [sum(x) for x in X]

model = Model(size=2)
model.train(X, y)

a = int(input('a: '))
b = int(input('b: '))

res = model.forward([a, b])
print(f"Przewidywany wynik dla {a} + {b} = {res}")
for w in model.weights:
    print(w)
