import time,os,random
def bar1():
    mul = 1
    for i in range(100):
        if '0' in str(i):
            mul += 1
        print(f"{i+1}% - {'#'*mul}")
        x = random.randint(1,10)
        if x in range(1,8):
            time.sleep(random.uniform(0.1,0.2))
        elif x in range(9,10):
            time.sleep(random.uniform(0.3,0.5))
        os.system("clear")
        
def bar2(title=''):
    mul = 1
    for i in range(100):
        if '0' in str(i):
            mul += 1
        print(f"{title} | {'='*mul} ~ {i+1}%")
        time.sleep(0.1)
        os.system("clear")

def bar_advanced(title='Loading', length=30, speed_range=(0.1, 0.4), variance_range=(0.3, 0.5)):
    mul = 1
    progress_char = '#'
    fill_char = '-'
    for i in range(100):
        if '0' in str(i): mul += 1
        filled_length = int(length * (i + 1) // 100)
        bar = progress_char * filled_length + fill_char * (length - filled_length)
        print(f"\033[92m{title}\033[0m | \033[94m[{bar}]\033[0m {i + 1}%")
        x = random.randint(1, 10)
        if x in range(1, 8):
            time.sleep(random.uniform(*speed_range))
        elif x in range(9, 10):
            time.sleep(random.uniform(*variance_range))
        os.system("cls" if os.name == "nt" else "clear")
    print(f"\033[92m{title} | Complete! \033[0m")    

#bar2("DATABASE")
#bar_advanced("KERNEL FILE CONN STATUS",length=50, speed_range=(0.05, 0.15), variance_range=(0.2, 0.4))