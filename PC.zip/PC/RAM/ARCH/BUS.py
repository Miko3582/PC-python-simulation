
#! DO NOT EDIT!
DATA_ = 16
ADDR_ = 8
CONTROL_ = 8

class BUS_R:
    def __init__(self):
        self.data = [[0 for _ in range(8)] for _ in range(2)]
        self.addr = [0 for _ in range(8)]
        self.control = [0 for _ in range(8)]

    #& DATA
    def set_data(self, data_to_write, sector=0):
        self.data[sector] = data_to_write[sector]
        self.data[sector+1] = data_to_write[sector+1]

    def get_data(self, sector=0):
        return self.data[sector]

    #& ADDR        
    def set_addr(self, addr_to_write):
        self.addr = addr_to_write

    def get_addr(self):
        return self.addr
    
    #& CONTROL
    def set_reg(self, reg, sector):
        self.control[sector] = reg

    def get_reg(self):
        return self.control

class BUS_W:
    def __init__(self):
        self.data = [[0 for _ in range(8)] for _ in range(2)]
        self.addr = [0 for _ in range(8)]
        self.control = [0 for _ in range(8)]

    #& DATA
    def set_data(self, data_to_write, sector=0):
        self.data[sector] = data_to_write[sector]
        self.data[sector+1] = data_to_write[sector+1]

    def get_data(self, sector=0):
        return [self.data[sector], self.data[sector+1]]

    #& ADDR        
    def set_addr(self, addr_to_write):
        self.addr = addr_to_write

    def get_addr(self):
        return self.addr
    
    #& CONTROL
    def set_reg(self, reg, sector):
        self.control[sector] = reg

    def get_reg(self):
        return self.control