from .decoder import DECODER as DEC

class ALLOCATION:
    
    def __init__(self):
        self.DEC = DEC()
    
    def WRITE(self, RAM, PA, to_write):
        _, S = self.DEC.DECODE(PA)
        check = _[3]
        if check == 63: _[3] -= 2
        RAM[_[0]][_[1]][_[2]][_[3]] = to_write[0]
        RAM[_[0]][_[1]][_[2]][_[3]+1] = to_write[1]
        
        return RAM, S

    def READ(self, RAM, PA):
        _, S = self.DEC.DECODE(PA)
        return RAM[_[0]][_[1]][_[2]][_[3]], S