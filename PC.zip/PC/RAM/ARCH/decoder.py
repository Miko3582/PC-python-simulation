class DECODER:
    def __init__(self):
        
        ranges_path = r"/home/raw/Pulpit/PC/RAM/core/SEGMENT_ADDR_RANGES"
        self.addr_ranges = {}
        self.SEC_SEGMENTS = ['ARCH', 'CORE', 'SYST', 'USER']

        with open(ranges_path, 'r') as f:
            for line, sec in zip(f.readlines(), self.SEC_SEGMENTS):
                if line.startswith(sec):
                    addrs = line.split(f"{sec}==")[1].strip()
                    addrs = addrs.replace('[', '').replace(']', '').split('-')
                    self.addr_ranges[sec] = [int(addr, 16) for addr in addrs]

    def RANGES(self, start, stop, addr):
        return start <= addr <= stop

    def DECODE(self, PA:list[int]):
        
        int_addr = int(''.join(map(str, PA)), 2)
        bank = int(''.join(map(str, PA[0:2])), 2)
        layer = int(''.join(map(str, PA[2:7])), 2)
        col = int(''.join(map(str, PA[7:13])), 2)
        offset = int(''.join(map(str, PA[13:19])), 2)
        VA = [bank, layer, col, offset]
        
        c=0
        for k, (start, stop) in self.addr_ranges.items():
            c+=1
            if self.RANGES(start, stop, int_addr):
                S = k; break
        return VA, S
