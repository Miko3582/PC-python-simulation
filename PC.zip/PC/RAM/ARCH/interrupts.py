class INTERRUPTS:
    def __init__(self):
        pass