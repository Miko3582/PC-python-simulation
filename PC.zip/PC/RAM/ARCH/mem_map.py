class MAPING:
    
    def __init__(self):
        pass
    
    #! P-ADDRESS
    
    def PA_VA(self):
        pass
    
    def PA_value(self):
        pass
    
    def PA_section(self):
        pass
    
    def PA_usage(self):
        pass
    
    def PA_loc(self):
        pass
    
    #! V-ADDRESS
    
    def VA_PA(self):
        pass
    
    def VA_value(self):
        pass
    
    def VA_section(self):
        pass
    
    def VA_usage(self):
        pass
    
    def VA_loc(self):
        pass
    
    