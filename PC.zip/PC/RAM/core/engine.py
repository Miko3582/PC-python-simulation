import time, random as r, sys, os
import threading as t
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '../')))

class RAM:
    
    def __init__(self,turn_on=False, cycles=0):
        
        #& 
        self.COUNTER = 0
        self.COUNTER_LIMIT = cycles
        self.running = turn_on
        #? dont needed anymore cos of  
        self.while_reading = False
        self.buff_w1 = r'/home/raw/Pulpit/PC/RAM/ARCH/BUFFERS/INST_OPEN_BUFFER_DATA_W1'
        self.buff_w2 = r'/home/raw/Pulpit/PC/RAM/ARCH/BUFFERS/INST_OPEN_BUFFER_DATA_W2'
        self.buff_r = r'/home/raw/Pulpit/PC/RAM/ARCH/BUFFERS/INST_OPEN_BUFFER_DATA_R'
        #&
        
        #! SECTIONS -- HEX
        self.sections = {
            "ARCH": (0x0, 0x1FF),
            "CORE": (0x200, 0x3FF),
            "SYST": (0x400, 0x5FF),
            "USER": (0x600, 0x3FFFFF),
        }
        
        #! FLAGS
        self.FLAG = {
            'WE': 0,
            'RE': 0,
            'CS': -1,
            'OE': 0,
            'BW': 0,
            'BR': 0,
            'DR': 0,
            'RB': 0,
        }
        """
        WE – Write Enable (włącz zapis)\n
        RE – Read Enable (włącz odczyt)\n
        CS – Chip Select (wybór układu)\n
        OE – Output Enable (włącz odczyt z pamięci)\n
        BW – Bus Write (zapis przez magistralę)\n
        BR – Bus Read (odczyt przez magistralę)\n
        DR – Data Ready (dane gotowe do odczytu)\n
        RB – Gotowość/Zajętość pamięci\n
        """
        
        #! REGISTERS
        self.REG = {
            'BS': 0,
            'AS': -1, #* default -1 [NotExists] | 0 is for ARCH !
            'CO': 0
        }
        """
        BS - Buffer Sector\n
        AS - Address Section\n
        CO - Check Only\n
        """
        
        #! PMS GENERATE
        MATRIX = self.PREPARE()
        PHYSICAL_MEMORY_STRUCTURE = [[[[[0 for _ in range(MATRIX[4])]
                                          for _ in range(MATRIX[3])]
                                         for _ in range(MATRIX[2])]
                                        for _ in range(MATRIX[1])]
                                       for _ in range(MATRIX[0])]
        self.PMS_DEEP = len(PHYSICAL_MEMORY_STRUCTURE)
        self.PMS = PHYSICAL_MEMORY_STRUCTURE
        
        #! IMPORTS
        from ARCH.alloc import ALLOCATION
        from ARCH.interrupts import INTERRUPTS
        from ARCH.mem_map import MAPING
        from ARCH.BUS import BUS_R, BUS_W
        
        #! MODULE-LINKS
        self.ALLOC = ALLOCATION()
        #? its faster method 
        x=self.ALLOC.DEC
        
        self.INTER = INTERRUPTS()
        self.MAP = MAPING()
        self.BUSR = BUS_R()
        self.BUSW = BUS_W()
        
    def PREPARE(self):
        
        self.global_path = r'/home/raw/Pulpit/PC/RAM/config/global.cfg'
        with open(self.global_path, 'r+') as f:
            for line in f:
                
                if line.startswith("SIZE"):
                    SIZE = line.strip().split('SIZE=')[1]
                if line.startswith("BANKS"):
                    BANKS = int(line.strip().split('BANKS=')[1])
                if line.startswith("LAYERS"):
                    LAYERS = int(line.strip().split('LAYERS=')[1])
                if line.startswith("COLUMNS"):
                    COLUMNS = int(line.strip().split('COLUMNS=')[1])
                if line.startswith("ROWS"):
                    ROWS = int(line.strip().split('ROWS=')[1])
                if line.startswith("OFFSET"):
                    OFFSET = int(line.strip().split('OFFSET=')[1])
                    
        return [BANKS,LAYERS,COLUMNS,ROWS,OFFSET]

    def GENERATE_FILES(self):
        data = [[str(r.randint(0,1)) for _ in range(8)] for _ in range(2)]
        section = r.choice(list(self.sections.keys()))
        start, stop = self.sections[section]
        addr = r.randint(start, stop)
        addr = ' '.join(f"{addr:022b}")
        ctrl = ' '.join([str(r.randint(0,1)) for _ in range(8)])
        if ''.join(addr) == '1'*22: addr = [str(r.randint(0,1)) for _ in range(22)]
            
        return data, addr, ctrl
    
    def READ_ROUTIN(self):
        #! READ
        
        # BR flag = 1
        with open(self.buff_w1, 'r+') as f:
            lines = f.readlines()
        try:
            addr=[int(x) for x in lines[2].split()]
            regs=[int(x) for x in lines[3].split()]
        except: return
            
        # save ADDR-BUS in buff
        self.BUSR.set_addr(addr_to_write=addr)
        
        # choose addr section to read
        self.REG['AS'] = regs[7]
        
        # set RE flag to 1
        self.FLAG['RE'] = 1
        
        # active CS
        self.FLAG['CS'] = 1
        
        # send data from addr
        data, S = self.ALLOC.READ(self.PMS,
            PA=self.BUSR.get_addr())
        data = [str(x) for x in data]
        
        # BW = 1
        if self.FLAG['BW'] == 1:
            with open(self.buff_r, 'w+') as f:
                f.write(' '.join(data))
        
        # active OE
        self.FLAG['EO'] = 1
        
        # send write-confirm signal
        #       +
        # reset flags
        for k,_ in self.FLAG.items():
            if k == 'DR' or k == 'RB':
                self.FLAG[k] = 1
            else:
                self.FLAG[k] = 0
                
        print(f"{hex(int(''.join(str(x) for x in addr)))} -> SECTOR: {S}\n")
        
    def WRITE_ROUTIN(self):
        #! WRITE
        
        # BR flag = 1
        
        with open(self.buff_w2, 'r+') as f:
            lines = f.readlines()
        try:
            data_1=[int(x) for x in lines[0].split()]
            data_2=[int(x) for x in lines[1].split()]
            addr=[int(x) for x in lines[2].split()]
            regs=[int(x) for x in lines[3].split()]
        except: return
            
        # save DATA-BUS in buff
        #? do not use 'sector' in `set_data()` func 
        #? cos it pern set to 0 for x16 DATA BUS [2x8-b pack]
        self.BUSW.set_data(data_to_write=[data_1, data_2])
        
        # save ADDR-BUS in buff
        self.BUSW.set_addr(addr_to_write=addr)
        
        # save CTRL-BUS in buff
        for reg, val in enumerate(regs):
            self.BUSW.set_reg(reg=val, sector=reg)
        
        # choose addr section to write | last bit
        self.REG['AS'] = regs[7]
        
        # set WE flag to 1
        self.FLAG['WE'] = 1
        
        # active CS & OE
        self.FLAG['CS'] = 1
        self.FLAG['EO'] = 1
        
        # write data at addr
        self.PMS, S = self.ALLOC.WRITE(RAM=self.PMS,
                        PA=self.BUSW.get_addr(),
                        to_write=self.BUSW.get_data())
        
        # send write-confirm signal
        #       +
        # reset flags
        for k,_ in self.FLAG.items():
            if k == 'DR' or k == 'RB':
                self.FLAG[k] = 1
            else:
                self.FLAG[k] = 0
                
        print(f"{hex(int(''.join(map(str, addr)), 2))} -> SECTOR: {S}\n")
        print(f"{hex(int(''.join(map(str, addr)), 2)+1)} -> SECTOR: {S}\n")
    
    def CONTROL(self, cpu_signal:int):
        while self.running:
            self.COUNTER += 1
            if self.COUNTER >= self.COUNTER_LIMIT:
                break
            
            self.REG['AS'] = r.randrange(0,3)
            self.FLAG['RB'] = 1
            self.FLAG['BR'] = 1
            data, addr, ctrl = self.GENERATE_FILES()
            
            with open(self.buff_w1,'w+') as f:
                f.write(f"{' '.join(data[0])}\n")
                f.write(f"{' '.join(data[1])}\n")
                f.write(f"{addr}\n")
                f.write(f"{ctrl}\n")
                
            with open(self.buff_w2,'w+') as f:
                f.write(f"{' '.join(data[0])}\n")
                f.write(f"{' '.join(data[1])}\n")
                f.write(f"{addr}\n")
                f.write(f"{ctrl}\n")
                
            if cpu_signal == 0:
                self.WRITE_ROUTIN()
                
            elif cpu_signal == 1:
                self.READ_ROUTIN()
    
    def BASE(self):
        while self.running:
            self.COUNTER += 1
            if self.COUNTER >= self.COUNTER_LIMIT:
                break
            
            if self.FLAG['RB'] == 1:
                print('RB FLAG | Control Signal Detected')
            
            if self.FLAG['CS'] == 1: self.FLAG['CS'] = r.randint(0,3)
                
            if self.FLAG['OE'] == 1:
                print('OE FLAG')
                with open(self.buff_r,'r+') as f: print(f.read())
                    
            if self.FLAG['DR'] == 1:
                print('DR FLAG')
                with open(self.buff_w1,'r+') as f: print(f.read())
                with open(self.buff_w2,'r+') as f: print(f.read())
            
            self.REG['BS'] = r.randint(0,1)