import threading as t, random as r, time, sys, os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '../../')))
from RAM.core.engine import RAM as RAM
#print(os.path.abspath(os.path.join(os.path.dirname(__file__), '../')))

def OROW():
    ram1 = RAM(turn_on=True,cycles=12000)
    start = time.time()
    threads = [
        t.Thread(target=ram1.CONTROL, args=(0,)),
    ]
    
    for th in threads:
        time.sleep(0.1)
        th.start()
        
    for th in threads:
        th.join()
        
    stop = time.time()
    print(f'Done in time: {round(stop-start, 5)}s')

    #*  calc rows using condition if any cell is 1
    #*  mul by 8 to receive used B
    
    B_mem_usage = 8*sum(1
            for bank in ram1.PMS 
            for layer in bank 
            for col in layer 
            for row in col
            if any(row))
    print(f"RAM: {round(B_mem_usage/1024/1024, 5)}/4 MB")
    
    
#OROW()
