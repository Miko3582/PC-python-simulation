import random

class CPU:
    def __init__(self):
        
        self.RESULT = []
        self.CMP_FLAG = None
        self.DEC_VALUE = 1
        self.INC_VALUE = 1
        self.range = [0x01, 0x100]
        self.DATA_SEGMENT = [0x101, 0x00]
        
        self.GPR = {
            'eax': 0,
            'ebx': 0
        }
        
        self.MEM = {hex(x): "nvc" for x in range(self.range[0], self.range[1])}
        self.AVT = []
        
        self.PC = 0
    
    def show_result(self):
        print(f"DATA SEGMENTS: {hex(self.DATA_SEGMENT[0])} -- {hex(self.DATA_SEGMENT[1])}")
        print("REGISTERS: ")
        for REG_name, REG_value in self.GPR.items():
            print(f"{REG_name} -> {REG_value}")
        print(f"CMP FLAG: {self.CMP_FLAG}")

    
    def RAM(self, opcode, args):
        self.AVT = [x for x in range(len(args))]
        
        for instr in opcode:
            PA = hex(random.randint(self.range[0], self.range[1]))

            while self.MEM.get(PA, None) == "nvc":
                self.MEM[PA] = instr
                
                PA_int = int(PA, 16)
                if PA_int < self.DATA_SEGMENT[0]:
                    self.DATA_SEGMENT[0] = PA_int
                if PA_int > self.DATA_SEGMENT[1]:
                    self.DATA_SEGMENT[1] = PA_int

                PA = hex(random.randint(self.range[0], self.range[1]))

        for i, arg in enumerate(args):
            self.AVT[i] = arg
    
    def ALU(self):
        while self.PC < len(self.MEM):
            instr = self.MEM.get(hex(self.PC), None)
            if instr == "nvc":  #! Jeśli na tym adresie nie ma instrukcji, przejdź dalej
                self.PC += 1
                continue
            
            if self.PC >= len(self.AVT):
                print(f"Warning: PC ({self.PC}) out of range for AVT.")
                break
            
            #! MOV
            if instr == '0x01':
                args = str(self.AVT[self.PC]).split()
                for i, arg in enumerate(args):
                    if arg in self.GPR:
                        if i == 0:
                            self.GPR[arg] = int(args[1]) if args[1].isdigit() else self.GPR[args[1]]
                        elif i == 1:
                            self.GPR[arg] = int(args[0]) if args[0].isdigit() else self.GPR[args[0]]

            #! ADD
            elif instr == '0x02':
                RESULT = sum(int(self.GPR[arg]) for arg in self.AVT[self.PC] if arg in self.GPR)
                self.GPR[args[0]] = RESULT

            #! DEC
            elif instr == '0x03':
                arg = self.AVT[self.PC]
                self.GPR[arg] -= self.DEC_VALUE

            #! CMP
            elif instr == '0x04':
                args = str(self.AVT[self.PC]).split()
                TO_CMP = [self.GPR[arg] for arg in args if arg in self.GPR]
                self.CMP_FLAG = TO_CMP[0] == TO_CMP[1]

            #! HLT
            elif instr == '0x05':
                self.PC = len(self.MEM)

            self.PC += 1