from cpu import CPU

class PARSER:
    
    def __init__(self):
        
        self.INSTRUCTIONS = {
            "MOV": "0x01",
            "ADD": "0x02",
            "DEC": "0x03",
            "CMP": "0x04",
            "HLT": "0x05",
        }
        
        self.file = r'/home/raw/Pulpit/PC/TEST/asm/test.asm'
        
    def maping(self):
        
        opcode = []
        args = []
        
        for line in self.lines:
            instr = line.split()[0]
            arg = " ".join(line.split()[1:])
            
            if instr.upper() in self.INSTRUCTIONS:
                opcode.append(self.INSTRUCTIONS[instr.upper()])
                args.append(arg)

        return opcode, args

    def main(self):
        with open(self.file, 'r+') as f:
            self.lines = f.readlines()

        opcode, args = self.maping()
        
        self.cpu = CPU()
        self.cpu.RAM(opcode, args)
        self.cpu.ALU()
        self.cpu.show_result()
    
parser = PARSER()
parser.main()