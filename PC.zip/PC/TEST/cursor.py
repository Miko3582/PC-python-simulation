import time, os , random

class CURSOR:
    
    def __init__(self, x, y):
        self.x = x
        self.y = y
    
    def clear(self, x, y):
        self.screen = [['.' for _ in range(self.y)] for _ in range(self.x)]

    def update(self, position):
        self.clear(position[0],position[1])
        self.screen[position[0]][position[1]] = 'x'
        
    def show(self):
        for px in self.screen:
            print('  '.join(px))
            
            
x=12
y=18
cursor = CURSOR(x, y)
cursor.clear(x, y)
position = [x//2, y//2]
while  True:
    x = random.randrange(position[0]-1, position[0]+1) if position[0] > 0 else position[0]+1
    y = random.randrange(position[1]-1, position[1]+1) if position[0] > 0 else position[0]+1
    position = [x, y]
    cursor.update(position)
    cursor.show()
    time.sleep(0.5)
    os.system('clear')