import os, random
path = r'/home/raw/Pulpit/PC/OS/dev/E'

# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #

# CREATE DISK

def MAKE_KERNEL_FILES():
    
    # FILES TREE-GENERATING
    boot_path = os.path.join(path,'boot')
    ver = [str(random.randint(10,999)) for _ in range(3)]
    ver = '.'.join(ver)
    kernel_dirs = [
        'initrd.img',
        'initramfs.img',
        'grub.cfg',
        'boot.img',
        'system.map',
        f'vmlinuz-{ver}-generic'
        ]

    # TREE-CREATING
    for kernel_dir in kernel_dirs:
        if kernel_dir == 'grub.cfg':
            MODE = int(input("DEV_MODE [0/1]: "))
            with open(os.path.join(boot_path, kernel_dir), 'w+') as f:
                f.write(f"MODE={MODE}\n")
        else:
            with open(os.path.join(boot_path, kernel_dir), 'w+') as f: ...
    print('COMPLETED: boot section')

def MAKE_BLOCKS_AND_PAGES():
    
    data_path = os.path.join(path,'data')
    
    # GET DATA
    with open(os.path.join(path,'superblock.cfg'), 'r+') as f:
        for line in f:
            if line.startswith('pages_per_block='):
                ppb = int(line.strip().split('pages_per_block=')[1])
            if line.startswith('ALL_blocks='):
                blocks = int(line.strip().split('ALL_blocks=')[1])
    
    # BLOCK-PAGES -> GENERATOR    
    for i in range(blocks):
        block = os.path.join(data_path,f'block_00{i}')
        os.mkdir(block)
        i += 1
        for j in range(ppb):
            page = os.path.join(block, f'page_00{j}')
            with open(page, 'w+') as f: ...
            j += 1
            
    print('COMPLETED: data section')
            
def MAKE_DIRS():

    # DIRS
    dirs = ['inodes','data','root','meta','logs','boot','part']
    root_dirs = ['media','home','etc','var','usr']
    log_dirs = ['part.log','errors.log','sys.log','operations.log']
    
    # EDIT -- PARTITION VALUES
    data_to_write = [
            "ALL_blocks=32",
            "ALL_pages=2048",
            "size_per_page=4096",
            "pages_per_block=64",
            "dirs_max_deep=16",
            "max_dir_size=61440",
            "max_file_size=4096",
            "max_pages_per_file=1",           
            "max_files_per_dir=15",
            "DISK_SIZE=8388608"
        ] # DEFAULT VALUES FOR TESTS
    
    # SUPERBLOCK
    with open(os.path.join(path,'superblock.cfg'), 'w+') as f:
        items = ''
        for item in data_to_write:
            items += f'{item}\n'
        f.write(items)
        
    with open(os.path.join(path,'superblock.cfg'), 'r+') as f:
        for line in f:
            if line.startswith('ALL_pages='):
                pages = int(line.strip().split('ALL_pages=')[1])
    
    # FILES TREE-GENERATING
    for dir in dirs:
        os.mkdir(os.path.join(path,dir))
        
        if dir == 'logs':
            logs_path = os.path.join(path,dir)
            for log_dir in log_dirs:
                with open(os.path.join(logs_path,log_dir), 'w+') as f: ...
            print('COMPLETED: logs section')
        
        if dir == 'inodes':
            inodes_path = os.path.join(path,dir)
            
            for k in range(pages):
                with open(os.path.join(inodes_path, f'inode_00{k}'), 'w+') as f: ...
                k += 1
            print('COMPLETED: inodes section')
            
        if dir == 'part':
            part_path = os.path.join(path,dir)
            with open(os.path.join(part_path, f'part_table.meta'), 'w+') as f: ...
            print('COMPLETED: part section')
    
    # ROOT
    root_path = os.path.join(path,'root')
    for root_dir in root_dirs:
        os.mkdir(os.path.join(root_path,root_dir))
    print('COMPLETED: root section')

    # META
    meta_path = os.path.join(path, 'meta')
    with open(os.path.join(meta_path,'superblock.cfg'), 'w+') as f: ...
    with open(os.path.join(meta_path,'bitmap_blocks.dat'), 'w+') as f: ...
    with open(os.path.join(meta_path,'bitmap_inodes.dat'), 'w+') as f: ...
    
    print('COMPLETED: meta section')

# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #

# MAIN START
os.system('clear')

MAKE_DIRS()
MAKE_BLOCKS_AND_PAGES()
MAKE_KERNEL_FILES()