import os, time
gpath = r'/home/raw/Pulpit/PC/OS/dev/E'

def MAKE_DIRS():
    # for now size will be 32MB not 128MB (for faster tests & writing process)
    
    size = 32 * 1024 * 1024 # in bytes
    block_size = 4096 # in bytes
    blocks = int(size / block_size)
    
    dirs = ['meta', 'root', 'data', 'logs', 'boot', 'part']
    root_dirs = ['media', 'home', 'etc', 'var', 'usr']
    log_files = ['part.log', 'err.log', 'sys.log', 'op.log', "i.log", "o.log", "io.log", "dv.log", "root.log"]
    meta_files = ["dirs.meta", "files.meta", "links.meta", "alloc.meta", "perm.meta", "logs.meta", "cfg.meta", "temp.meta"]
    boot_files = ["bootloader.bin", "kernel.core", "config.boot", "boot.log"]
    part_files = ["part_table.part", "mounted.part", "fs_table.part"]
    
    os.mkdir(gpath)
    path = gpath
    
    for dir in dirs:
        os.makedirs(os.path.join(path, dir), exist_ok=True)
        
        if dir == "meta":
            meta_path = os.path.join(path, "meta")
            for file in meta_files:
                with open(os.path.join(meta_path, file), "w+") as f: ...
        
        if dir == "data":
            data_path = os.path.join(path, dir)
            meta_alloc_file = os.path.join(path, "meta", "alloc.meta")
            for i in range(blocks):
                with open(os.path.join(data_path, f"block_{i}"), "w+") as f: ...
                with open(meta_alloc_file, "+a") as f:
                    f.write(f'block_{i}: FREE; 0\n')
                
        if dir == "root":
            root_path = os.path.join(path, dir)
            for root_dir in root_dirs:
                os.mkdir(os.path.join(root_path, root_dir))
            
        if dir == "logs":
            logs_path = os.path.join(path, dir)
            for file in log_files:
                with open(os.path.join(logs_path, file), 'w+') as f: ...
        
        if dir == "boot":
            boot_path = os.path.join(path, dir)
            for file in boot_files:
                with open(os.path.join(boot_path, file), "w+") as f: ...
            
        if dir == "part": 
            part_path = os.path.join(path, dir)
            for file in part_files:
                with open(os.path.join(part_path, file), "w+") as f: ...
        
#MAKE_DIRS()