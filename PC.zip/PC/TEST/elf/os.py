import os

data_path = r"/home/raw/Pulpit/PC/TEST/elf/data"

def ELF_generate(name, arch, filetype):
    #! bite size = ~350
    with open(os.path.join(data_path, name), 'r+') as f:
        lines = f.readlines()
    
    content = f[
        "[H[",
        "E_IDENT=0x7f 45 4c 46",
        f"E_TYPE={filetype}",
        f"E_MACHINE={arch}",
        "E_VERSION=1.73.2.514",
        "E_ENTRY=",
        "E_PHOFF=0",
        "E_SHOFF=0",
        "E_FLAGS=0x01",
        f"E_EHSIZE={len(content)}",
        "E_PHENTSIZE=",
        "E_SHENTSIZE=",
        "E_PHNUM=",
        "E_SHNUM=",
        "E_SHSTRNDX=0",
        "]H]",]
    
    lines = ["[T[", lines, "]T]"]
    
    with open(os.path.join(data_path, name), 'w+') as f:
        for line in content:
            f.write(f"{line}\n")
        f.write("[H[$$]T]\n")
        for line in lines:
            f.write(f"{line}\n")
        f.write("[H[$$]T]\n")

class OS:
    
    def __init__(self):
        #PID: []
        self.P = {}
    
    def PMU(self): ...

    def shell(self):
        cmd = input("$ ")
        if cmd.startswith('run'):
            pass
    