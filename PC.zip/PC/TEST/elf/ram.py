import random, time

class RAM:
    
    def __init__(self):
        self.MEMORY = {hex(x):[hex(x+10000),[]] for x in range(0x10000,0x20000)}
        
    def read(self, VA):
        _, data = self.MEMORY[VA]
        return data
    
    def write(self, VA, data):
        PA,_ = self.MEMORY[VA]
        self.MEMORY[VA] = (PA, data)
        return PA
    
    
ram = RAM()

x1 = time.time()
for i in range(9999):
    VA = hex(random.randint(0x10000,0x20000))
    PA = ram.write(VA, data=random.randint(0,9))
    res = ram.read(VA)
    print(f"[{VA.upper()}]-[{PA.upper()}] -> '{res}'")

c = 0   
for k,v in ram.MEMORY.items():
    if v[1] != []:
        c+=1
        print(f"[{k.upper()}]-[{v[0].upper()}] -> {v[1]}")

x2 = time.time()
print(f"Address in use: {c}/{len(ram.MEMORY)}")
print(f"Time [s]: {round(x2-x1, 5)}")