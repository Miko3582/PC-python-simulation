import os

# Funkcja do aktualizacji pliku konfiguracyjnego
def update_config_file(file_path, params):
    try:
        with open(file_path, 'r') as f:
            content = f.readlines()

        # Przeglądaj plik i aktualizuj wartości na podstawie 'params'
        for i, line in enumerate(content):
            for key, value in params.items():
                if line.startswith(key):
                    content[i] = f"{key}={value}\n"

        # Zapisz zaktualizowany plik
        with open(file_path, 'w') as f:
            f.writelines(content)

        print(f"Plik {file_path} zaktualizowany.")

    except Exception as e:
        print(f"Error podczas aktualizacji pliku {file_path}: {e}")

# Funkcja do zadawania pytań użytkownikowi
def get_user_input():
    params = {}

    # Przykładowe pytania
    print("Uzupełnij konfigurację systemu:")

    kernel_version = input("Podaj wersję jądra (np. 5.15.0): ")
    params['kernel_version'] = kernel_version

    compression_method = input("Wybierz metodę kompresji (np. gzip): ")
    params['compression_method'] = compression_method

    initramfs_path = input("Podaj ścieżkę do obrazu initramfs (np. /boot/initrd.img): ")
    params['initramfs_path'] = initramfs_path

    # Na podstawie podanego kernel_version ustaw inne parametry (np. domyślną liczbę rdzeni CPU)
    if kernel_version.startswith('5.15'):
        params['cpu_cores'] = '4'
    else:
        params['cpu_cores'] = '2'

    # Można tu dodać bardziej złożoną logikę zależności
    # np. jeśli wybór jądra '5.x', to zmienia ustawienie root_fs na 'ext4'
    if kernel_version.startswith('5'):
        params['root_fs'] = 'ext4'
    else:
        params['root_fs'] = 'btrfs'

    return params

# Główna funkcja instalatora
def installer():
    # Zapytaj użytkownika o parametry
    params = get_user_input()

    # Pliki konfiguracyjne
    config_files = [
        '/home/raw/Pulpit/PC/LIB/boot/vmlinuz-*.*.*-generic',  # Przykład pliku jądra
        '/home/raw/Pulpit/PC/LIB/boot/system.map',  # Przykład pliku mapy symboli
        '/home/raw/Pulpit/PC/LIB/boot/initrd.img',  # Przykład pliku systemu initramfs
    ]

    # Zaktualizuj odpowiednie pliki konfiguracyjne
    for file_path in config_files:
        update_config_file(file_path, params)

    print("\nInstalacja zakończona! Twój system jest gotowy do uruchomienia.")

# Uruchom instalatora
if __name__ == "__main__":
    installer()
