import random

class MODULE_001:
    
    def __init__(self):
        
                            #~ BITS
        self.BANKS = 4      #^ 2
        self.LAYERS = 32    #^ 5
        self.COLUMNS = 64   #^ 6
        self.ROWS = 64      #^ 6
        self.OFFSET = 8     #! 3 - CELLS [0-1 bit]
        self.LEN = 22       #^ 22
        
        #! MAIN MODULE STRUCTURE - 4 MB
        self.MAIN_OPERATING_MEMORY = [[[[[0 for _ in range(self.OFFSET)]
                                         for _ in range(self.ROWS)]
                                        for _ in range(self.COLUMNS)]
                                       for _ in range(self.LAYERS)]
                                      for _ in range(self.BANKS)]
        
        #! MAIN BUFFER STRUCTURE - 2B
        self.MAIN_OPERATING_BUFFER = [0 for _ in range(45)]
        """
        16-data [2xB]
        4-flags
        19-address
        """
        
    def MAPING(self, VA): ...
        
    def READ(self, VA:str):
        """
        VA len -> 19 bits:
        - B - 2 bits
        - L - 5 bits
        - C - 6 bits
        - O - 6 bits (instead of rows)
        """

        addr = [x for x in VA]
        
        bank = int(''.join(addr[0:2]), 2)
        layer = int(''.join(addr[2:7]), 2)
        col = int(''.join(addr[7:13]), 2)
        offset = int(''.join(addr[13:19]), 2)
        
        DATA = self.MAIN_OPERATING_MEMORY[bank][layer][col][offset]
                    
        DATA = [str(x) for x in DATA]
        return ''.join(DATA)

    def WRITE(self, VA:str, DATA:str):
        """
        ! VA len -> 19 bits:
        - B - 2 bits
        - L - 5 bits
        - C - 6 bits
        - O - 6 bits (instead of rows)
        
        ! DATA len -> 8 bits
        """
        
        #todo PA = self.MAPING(VA)
        data = [x for x in DATA]
        addr = [x for x in VA]

        bank = int(''.join(addr[0:2]), 2)
        layer = int(''.join(addr[2:7]), 2)
        col = int(''.join(addr[7:13]), 2)
        offset = int(''.join(addr[13:19]), 2)

        for i in range(len(DATA)):
            self.MAIN_OPERATING_MEMORY[bank][layer][col][offset][i] = int(data[i])
    
ram = MODULE_001()

for i in range(1, 50001):
    bank =  ''.join([str(random.randint(0,1)) for _ in range(2)])
    layer = ''.join([str(random.randint(0,1)) for _ in range(5)])
    col =   ''.join([str(random.randint(0,1)) for _ in range(6)])
    offset= ''.join([str(random.randint(0,1)) for _ in range(6)])
    data =  ''.join([str(random.randint(0,1)) for _ in range(8)])
    VA = f"{bank}{layer}{col}{offset}"
    ram.WRITE(VA, data)
    ram.READ(VA)
    if i % 10000 == 0:
        print(i)
    
print('a')
b_mem_usage = sum(1
            for bank in ram.MAIN_OPERATING_MEMORY 
            for layer in bank 
            for col in layer 
            for row in col
            if any(row))

B_mem_usage = b_mem_usage * 1

print(f"RAM: {round(B_mem_usage/1024/1024, 3)}/4 MB")