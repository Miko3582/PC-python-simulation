import random, time, os

class BIN_CONSOLE:
    
    def __init__(self):
        self.MEMORY = {hex(x):[hex(x+100),[]] for x in range(0x100,0x200)}
        
    def read(self, VA):
        PA, data = self.MEMORY[VA]
        return PA, data
    
    def write(self, VA, data):
        PA,_ = self.MEMORY[VA]
        self.MEMORY[VA] = (PA, data)
        return PA
    
    def main(self):
        os.system('clear')
        time.sleep(1)
        print("\nSyntax: OP INSTR VALUE1 VALUE2 VA")
        print("EG: W 0x03 5 3 0x150")
        print("W - write\n0x03 - '3' is ADD\n0x150 - VA address in RAM\n\n")
        
        print("OP: W - write, R - read")
        print("INSTR - 0x03 -> ADD")
        print("VA - in range 0x100; 0x200\n\n")
        
        print("If op is R, enter only VA, rest set at 0")
        
        while True:
            
            cmd = input('> ')
            time.sleep(1.5)
            
            if not cmd.split(): continue
            
            if cmd == 'exit':
                print("$ clearing RAM")
                time.sleep(4)
                print("$ exiting")
                time.sleep(1.5)
                break
            
            args = cmd.split()
            
            self.op = args[0]
            self.instr = args[1]
            self.value_1 = float(args[2])
            self.value_2 = float(args[3])
            self.VA = args[4]
            
            if int(self.VA, 16) not in range(0x100,0x200):
                print('$ WRONG VA!\n')
                continue
            
            if self.instr == "0x03":
                self.value_1 += self.value_2
            
            if self.op == 'W':
                PA = self.write(self.VA, self.value_1)
                print(f'$ write [{PA}]')
                
            elif self.op == 'R':
                PA, res = self.read(self.VA)
                print(f"$ read [{PA}] -> '{res}'")

            else:
                print('$ WRONG OP!\n')
                continue

bin_console = BIN_CONSOLE()
bin_console.main()