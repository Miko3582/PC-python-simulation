import random, time, os

class RAM:
    def __init__(self):
        self.path = r'/home/raw/Pulpit/PC/TEST/ram/layer'
        self.MAP = {hex(i): hex(i + 100) for i in range(1, 100)}
    
    def get_physical_address(self, vaddr):
        return self.MAP.get(vaddr, None)
    
    def write(self, vaddr, data):
        paddr = self.get_physical_address(vaddr)
        if not paddr:
            print(f"Error: Adres wirtualny {vaddr} nie ma przypisanego adresu fizycznego.")
            return

        with open(os.path.join(self.path, f'{paddr}.sys'), 'w+') as f:
            data = ''.join([str(ord(x)) for x in data])
            f.write(data)
        return paddr
    
    def read(self, vaddr):
        paddr = self.get_physical_address(vaddr)
        if not paddr:
            print(f"Error: Adres wirtualny {vaddr} nie ma przypisanego adresu fizycznego.")
            return
        try:
            with open(os.path.join(self.path, f'{paddr}.sys'), 'r+') as f:
                rdata = f.read()
        except FileNotFoundError:
            print(f"Error: Plik dla adresu {paddr} nie został znaleziony.")
            return
        return rdata

ram = RAM()
for i in range(50):
    data = ''.join([chr(random.randint(0, 100)) for _ in range(3)])
    vaddr = hex(random.randint(10, 100))
    paddr = ram.write(vaddr, data)
    rdata = ram.read(vaddr)
    print(f"{vaddr} -> {paddr}[{rdata}]")
    time.sleep(0.5)
    
    
input("Enter to clear RAM ")

for item in os.listdir(ram.path):
    os.remove(os.path.join(ram.path, item))