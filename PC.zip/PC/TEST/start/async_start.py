import threading as t
import time, random, os

class CONSOLE:
    
    def __init__(self, threads:list):
        
        #* SYS
        self.threads = threads
        self.cmd_close = False
        self.sys_ = False
        
        #* COUNTER
        self.CT_ = True
        self.ct_ = False
        self.c = 0
        self.c_timeout = 0.256
    
    def COUNTER(self):
        while self.CT_:
            if self.ct_ == True:
                print(f'COUNTER: {self.c}')
                self.ct_ = False
                time.sleep(0.6)
            self.c += 1
            time.sleep(self.c_timeout)
            
    def RAM(self):
        while True:
            if self.sys_ and self.cmd_close:
                time.sleep(0.1)
                usage = random.uniform(623.12,9511.42)
                print(f'\n-=| SYS-REPORT |=-\nRAM USAGE: {round(usage/1024,2)}/16 MB')
                time.sleep(10)

    def CPU(self):
        while True:
            if self.sys_ and self.cmd_close:
                time.sleep(0.2)
                usage = random.uniform(16.91,86.62)
                print(f'CORES USAGE: {round(usage,2)}%\n')
                time.sleep(10)
            
    def main(self):
        
        print('$ RUNNING TERMINAL')
        print('$ COMMAND_OPEN -> True')
        
        while True:
            
            time.sleep(0.4)
            self.cmd_close = False
            cmd = input('> ')
            
            if not cmd.split(): continue
            args = cmd.split()[1:]
            cmd = cmd.split()[0]
            
            if cmd == 'ct':
                
                print(f'COUNTER: {self.c}' if self.CT_ else 'COUNTER: OFF')
            
            if cmd == 'sys':
                self.sys_ = not self.sys_
                print('SYS_ Status: On' if self.sys_ else 'SYS_ Status: Off')

            
            if cmd == 'task':
                if len(args) >= 1:
                    if args[0] == '-l':
                        for thread in self.threads:
                            print(thread.name)
                    
                    if args[0] == '-k':
                        for thread in self.threads:
                                if args[1] == 'ct' and 'COUNTER' in thread.name:
                                    self.threads.remove(thread)
                                    print('`COUNTER` Status: KILLED')
                                    self.CT_ = False
                                    continue
                    
                    if args[0] == '-a':
                        if args[1] == 'ct':
                            th = t.Thread(target=self.COUNTER, name='COUNTER')
                            self.threads.append(th)
                            th.start()
                            print('`COUNTER` Status: CREATED')
                            self.CT_ = True
            
            if cmd == 'exit':
                os._exit(1)
                
            if cmd == 'cls':
                os.system('clear')
                
            if cmd == 'echo':
                print(' '.join(args))
                
            self.cmd_close = True

#! START ASYNC
os.system('clear')
sys_threads = []
console = CONSOLE(sys_threads)
sys_threads.extend([
    #~ default tasks
    t.Thread(target=console.main ,name='SYS'),
    t.Thread(target=console.CPU, name='CPUx16'),
    t.Thread(target=console.RAM, name='RAM_MOD'),
    t.Thread(target=console.COUNTER, name='COUNTER'),
])

for th in sys_threads:
    th.start()